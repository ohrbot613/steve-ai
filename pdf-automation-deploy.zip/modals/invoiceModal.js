const { default: mongoose } = require("mongoose");

const invoiceSchema = new mongoose.Schema(
    {
        invoiceDate: {
            type: Date,
        },

        invoiceXeroDate: {
            type: Date,
        },

        invoiceNumber: {
            type: String,
            required: true,
            index: true,
        },

        activityDescription: {
            type: String,
            default: null,
        },

        amountXero: {
            type: {
                amount: { type: Number, required: true },
                taxFees: { type: Number, required: true },
            },
        },

        amount: {
            type: {
                amount: { type: Number, required: true },
                taxFees: { type: Number, required: true },
            },
        },


        currency: {
            type: String,
            required: true,
            uppercase: true,
        },

        paymentStatus: {
            type: String,
            enum: ["paid", "unpaid"],
            required: true,
        },
        supplier: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Supplier",

        },
        log: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Logs",
        },
        addedAt: {
            type: Date,
            default: Date.now,
        },
    },

);
const Invoices = mongoose.model("Invoices", invoiceSchema);
module.exports = Invoices;
