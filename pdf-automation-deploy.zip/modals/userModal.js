const mongoose = require("mongoose");

const xeroSchema = new mongoose.Schema({
    id_token: { type: String, required: true },
    access_token: { type: String, required: true },
    refresh_token: { type: String, required: true },
    token_type: { type: String, default: "Bearer" },
    expires_in: { type: Number, required: true },
    expires_at: { type: Date, required: true },
    scope: { type: String },
    tenantId: { type: String, required: true }
}, { _id: false }); // _id false so it doesn’t create a separate ID for this subdocument

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    xero: xeroSchema, // embedded Xero object
    createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model("User", userSchema);

module.exports = User;
