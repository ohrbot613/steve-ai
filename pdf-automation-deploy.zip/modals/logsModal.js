const { default: mongoose } = require("mongoose");

const LogsSchema = new mongoose.Schema(
    {
        status: {
            type: String,
            enum: ['started', 'completed', 'failed'],
            default: 'started'
        },

        supplier: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Supplier",

        },
     
        total: {
            type: Number,
            default: 0
        },
        unmatched: {
            type: Number,
            default: 0
        },
      
         file: {
            type: String,
        },

        invoiceIssueDate: {
            type: Date,
        },
        addedAt: {
            type: Date,
            default: Date.now,
        },
        isSuperseded: {
            type: Boolean,
            default: false,
        },
    },

);
const Logs = mongoose.model("Logs", LogsSchema);
module.exports = Logs;
