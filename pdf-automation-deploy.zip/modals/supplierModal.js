const { mongoose } = require("mongoose");

const supplierSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true
        },
        xeroId: {
            type: String,
            required: true
        },
        addedAt: {
            type: Date,
            default: Date.now,
        },
    },

);
const Supplier = mongoose.model("Supplier", supplierSchema);
module.exports = Supplier;
