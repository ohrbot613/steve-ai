const { fileTypeFromBuffer } = require("file-type");
const { tryCatchAsync } = require("./ErrorController");
const fs = require("fs");
const XLSX = require('xlsx');
const mongoose = require("mongoose");
const { PDFParse } = require("pdf-parse");
const { findMatchingCompanyWithAI, formatWithAIToStandardJSON, findMatchingCompanyWithAIFromAList, checkMultipleInvoiceNumbers } = require("../formatting");
const axios = require("axios");
const Invoices = require("../modals/invoiceModal");
const Suppliers = require("../modals/supplierModal");
const Logs = require("../modals/logsModal");
const path = require("path");
const { v4: uuidv4 } = require("uuid"); // for unique IDs
const multer = require('multer');

const storage = multer.memoryStorage();


// File filter to only accept PDF and XLSX
const fileFilter = (req, file, cb) => {
    const allowedTypes = ['application/pdf',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];

    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true); // accept file
    } else {
        cb(new Error('Only PDF and XLSX files are allowed'), false); // reject file
    }
};

exports.upload = multer({ storage, fileFilter });


exports.parseFiles = tryCatchAsync(async (req, res) => {
    const accessToken = req.xeroAccessToken
    const tenantId = req.xeroTenantId



    function errorCallback(res, req, err) {
        console.log(err)
        return res.status(500).json(err);
    }

    async function loop(logic, message) {
        let attempts = 0;
        const maxAttempts = 3;
        let success = false;
        let data = false;

        while (!success && attempts < maxAttempts) {
            attempts++;

            try {
                data = await logic();
                success = true
            } catch (err) {
                console.log(err)
                success = false;
            }
        }

        if (!success) {
            console.error('Unable to complete after maximum attempts');
            throw new Error(message || 'Unable to complete after maximum attempts');
        }

        console.log("Success after", attempts, "attempts", success);

        return data
    }

    const fileName = req.file.originalname || 'unknown';
    let newFileName
    let dataForAi = await parseFile()

    async function parseFile() {
        const fileBuffer = req.file.buffer;

        const folderPath = path.join(__dirname, "../media/files"); // your folder
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true }); // make folder if not exists
        }

        const fileExtension = path.extname(fileName) || '.pdf';
        const uniqueName = uuidv4() + fileExtension; // keep original extension
        const savePath = path.join(folderPath, uniqueName);
        newFileName = uniqueName
        fs.writeFileSync(savePath, fileBuffer);

        const type = await fileTypeFromBuffer(fileBuffer);
        if (type.ext == 'xlsx' || type.ext == 'xls') {
            // Parse Excel from buffer instead of file path
            const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
            const allRecords = [];

            workbook.SheetNames.forEach(sheetName => {
                const sheet = workbook.Sheets[sheetName];
                const records = XLSX.utils.sheet_to_json(sheet, { defval: null });
                records.forEach(r => r.sheetName = sheetName);
                allRecords.push(...records);
            });

            return allRecords
        } else if (type.ext == 'pdf') {
            const parser = new PDFParse({ data: fileBuffer });
            const fileData = await parser.getText();
            if (parser.destroy) await parser.destroy();
            return fileData.text
        } else {
            return errorCallback(res, req, `File type not supported ${type.ext}`);
        }
    }


    const companyArray = []

    async function getCompanyName(email, fileName, content) {
        await loop(async () => {
            const name = await findMatchingCompanyWithAI(email, fileName, content)
            if (!name || name.trim().length == 0) {
                return false
            }

            companyArray.push(name)
            companyArray.push(...name.replace(/[^a-zA-Z0-9\s]/g, '').split(" "))
            companyArray.push(...name.replace(/[^a-zA-Z0-9\s]/g, '').split(" ").map((item) => item.toUpperCase()))
            companyArray.push(...name.replace(/[^a-zA-Z0-9\s]/g, '').split(" ").map((item) => item.toLowerCase()))
            companyArray.push(
                ...name
                    .replace(/[^a-zA-Z0-9\s]/g, '')
                    .split(" ")
                    .map(item => item.charAt(0).toUpperCase() + item.slice(1).toLowerCase())
            );
        }, "Failed to get company name from AI")

    }

    const email = ''
    let invoiceIssueDate
    await getCompanyName(email, fileName, dataForAi)

    const invoicesFromFile = await loop(async () => {
        // Convert data to string format for AI processing
        const dataString = typeof dataForAi === 'string' ? dataForAi : JSON.stringify(dataForAi);
        const format = await formatWithAIToStandardJSON(dataString, fileName);

        const removeJSON = format.replace(/```/gi, '').replace(/JSON/gi, '');
        const invoicesObj = JSON.parse(removeJSON);
        function toValidDate(value) {
            if (!value) return null;
            
            const date = new Date(value);
            return isNaN(date.getTime()) ? null : date;
        }
        
        console.log(invoicesObj.fileDate, toValidDate(invoicesObj.fileDate))
        // usage
        invoiceIssueDate = toValidDate(invoicesObj.fileDate)
         return invoicesObj.invoices.map(inv => ({ ...inv, invoiceNumber: inv.invoiceNumber }))
    }, 'Failed to format file data with AI')


    const contactsArray = await (async () => {
        const filter = companyArray
            .filter(word => word.trim() !== "")
            .map(word => `Name.Contains("${encodeURIComponent(word)}")`)
            .join(" OR ");

        const url =
            `https://api.xero.com/api.xro/2.0/Contacts?where=${filter}`


        const response = await axios.get(url, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Xero-tenant-id': tenantId,
                Accept: 'application/json'
            }
        });
        // const contacts = response?.data?.Contacts;
        const allContacts = response?.data?.Contacts || [];
        const contacts = allContacts.filter(ct => ct.Balances);

        // Log the ones that were filtered out
        allContacts.forEach(ct => {
            if (!ct.Balances) {
                // console.log(`Filtered out: ${ct.Name}, Balance: ${ct.Balance || 0}`);
            }
        });
        if (contacts.length == 0) {
            return errorCallback(res, req, "No contacts found.")
        }


        return contacts;
    })();




    const contactId = await loop(async () => {
        const contactIdJson = await findMatchingCompanyWithAIFromAList(companyArray[0], fileName, email, contactsArray)
        const contactId = JSON.parse(contactIdJson.replace(/```json/gi, '').replace(/```/gi, '')).id

        const isXeroContactId = (id) =>
            /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);

        if (!isXeroContactId(contactId)) {
            throw new Error("No contact id found from AI")
        }

        return contactId
    })

    let supplierInfo = await Suppliers.findOne({ xeroId: contactId })
    if (!supplierInfo) {
        supplierInfo = await Suppliers.create({ xeroId: contactId, name: contactsArray.find((ct) => ct.ContactID == contactId).Name })
    }


    const logDoc = await Logs.create({ supplier: supplierInfo._id, status: 'started', file: newFileName, invoiceIssueDate })
    try {


        async function getInvoicesFromXero() {
            const today = new Date();
            const twoMonthsAgo = new Date(today);
            twoMonthsAgo.setMonth(today.getMonth() - 2);

            const lastInvoiceFromSupplier = await Invoices.findOne({ supplier: supplierInfo._id }).sort({ createdAt: -1 })
            const date = new Date(lastInvoiceFromSupplier?.addedAt ?? twoMonthsAgo);
            const fromDate = `${date.getFullYear()},${String(date.getMonth() + 1).padStart(2, '0')},${String(date.getDate()).padStart(2, '0')}`;
            // TODO: update the dates
            const where = `
                            Contact.ContactID == Guid("${contactId}")
                            AND Date >= DateTime(${fromDate})`;


            const invoiceUrl = `https://api.xero.com/api.xro/2.0/Invoices?where=${encodeURIComponent(where)}`;
            const invoiceResponse = await axios.get(invoiceUrl, {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    'Xero-tenant-id': tenantId,
                    Accept: 'application/json',
                },
            });

            return invoiceResponse.data.Invoices
        }

        const invoicesArray = await getInvoicesFromXero()

        const formattedXeroInvoices = invoicesArray.map(inv => {
            return {
                invoiceDate: new Date(inv.DateString).toLocaleDateString('en-GB'),
                invoiceNumber: inv.InvoiceNumber,
                activityDescription: null, // fill if needed
                amount: {
                    amount: inv.SubTotal,
                    tax_fees: inv.TotalTax
                },
                currency: inv.CurrencyCode === 'USD' ? '$' : '€',
                paymentStatus: inv.Status === 'AUTHORISED' ? 'unpaid' : 'paid', // adjust mapping if needed
            };
        }).map(inv => ({ ...inv, invoiceNumber: inv.invoiceNumber?.replace(/\D/g, '') }))
        // .filter(inv => inv.paymentStatus === 'unpaid')

        function matchInvoices(formattedXeroInvoices, invoicesFromFile) {
            const mapXero = new Map();
            const mapFile = new Map();

            // Map invoices by InvoiceNumber
            formattedXeroInvoices.forEach(inv => mapXero.set(inv.invoiceNumber.replace(/\D/g, ''), inv));
            invoicesFromFile.forEach(inv => mapFile.set(inv.invoiceNumber.replace(/\D/g, ''), inv));

            // Get all unique InvoiceNumbers
            const allInvoiceNumbers = new Set([
                ...mapXero.keys(),
                ...mapFile.keys()
            ]);

            // Build pairs
            const items = [];
            allInvoiceNumbers.forEach(num => {
                const xeroInv = mapXero.get(num) || null;
                const fileInv = mapFile.get(num) || null;
                items.push([xeroInv, fileInv]);
            });

            return items;
        }

        function getInvoiceKeys(invoiceNumber) {
            const raw = invoiceNumber.trim();
            const digitsOnly = raw.replace(/\D/g, '');

            return new Set([
                raw,
                digitsOnly
            ]);
        }


        const matchedInvoices = matchInvoices(formattedXeroInvoices, invoicesFromFile);


        const mismatch = matchedInvoices.filter(
            item =>
                item[0] == null ||
                item[1] == null
        ).length;



        matchedInvoices.forEach(async ([xeroInv, fileInv]) => {
            await Invoices.create({
                invoiceDate: fileInv ? new Date(fileInv.invoiceDate?.split('/').reverse().join('-')) : null,
                invoiceXeroDate: xeroInv ? new Date(xeroInv.invoiceDate?.split('/').reverse().join('-')) : null,
                invoiceNumber: fileInv ? fileInv.invoiceNumber : xeroInv.invoiceNumber,
                activityDescription: fileInv ? fileInv.activityDescription : null,
                amountXero: xeroInv ? { amount: xeroInv.amount.amount ?? 0, taxFees: xeroInv.amount.tax_fees ?? 0 } : null,
                amount: fileInv ? { amount: fileInv.amount.amount ?? 0, taxFees: fileInv.amount.tax_fees ?? 0 } : null,
                currency: fileInv ? fileInv.currency : xeroInv.currency,
                paymentStatus: fileInv ? fileInv.paymentStatus : xeroInv.paymentStatus,
                supplier: supplierInfo._id,
                log: logDoc._id 
            })
        })

        await Logs.updateOne({ _id: logDoc._id }, { status: `completed`, total: matchedInvoices, unmatched: mismatch })
        
        // Mark older logs as superseded (keep for Activity but hide from other views)
        if (invoiceIssueDate && supplierInfo?._id) {
            // Normalize date to compare only date part (without time)
            const normalizedDate = new Date(invoiceIssueDate);
            normalizedDate.setHours(0, 0, 0, 0);
            const nextDay = new Date(normalizedDate);
            nextDay.setDate(nextDay.getDate() + 1);
            
            // Mark older logs as superseded instead of deleting them
            await Logs.updateMany({
                supplier: supplierInfo._id,
                invoiceIssueDate: {
                    $gte: normalizedDate,
                    $lt: nextDay
                },
                _id: { $ne: logDoc._id }, // Exclude the current log
                addedAt: { $lt: logDoc.addedAt } // Only older logs
            }, {
                isSuperseded: true
            });
        }
        
        // res.redirect('/')
        res.status(200).json({
            success: true,
        });
    } catch (error) {
        await Logs.updateOne({ _id: logDoc._id }, { status: 'failed' })
        // res.redirect('/')
            res.status(200).json({
                success: false,
                text: []
            });
    }
});

exports.getInvoices = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const id = req.query.id;
    const sortBy = req.query.sortBy || 'systemDate';
    const sortOrder = req.query.sortOrder || 'asc';
    const offset = (page - 1) * limit;

    // Map frontend sort fields to database fields
    const sortFieldMap = {
        'referenceId': 'invoiceNumber',
        'supplierDate': 'invoiceDate',
        'systemDate': 'invoiceXeroDate',
        'supplierAmount': 'amount.amount',
        'systemAmount': 'amountXero.amount'
    };

    // Get the actual database field to sort by
    const dbSortField = sortFieldMap[sortBy] || 'invoiceXeroDate';
    
    // Build sort object
    const sortObj = {};
    sortObj[dbSortField] = sortOrder === 'desc' ? -1 : 1;

    const invoices = await Invoices.find({ log: id })
        .sort(sortObj)
        .populate('supplier')
        .populate('log')
        .skip(offset)
        .limit(limit);

    // If sorting by foundInSystem, we need to sort in-memory since it's a computed field
    if (sortBy === 'foundInSystem') {
        invoices.sort((a, b) => {
            const aFound = a.invoiceXeroDate ? 1 : 0;
            const bFound = b.invoiceXeroDate ? 1 : 0;
            return sortOrder === 'desc' ? bFound - aFound : aFound - bFound;
        });
    }

    const total = await Invoices.countDocuments({ log: id });
    res.status(200).json({
        success: true,
        invoices,
        pages: Math.ceil(total / limit)
    });
});

exports.getAllInvoices = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const offset = (page - 1) * limit;

    const invoices = await Invoices.find()
        .sort({ addedAt: -1 })  // Sort ascending
        .skip(offset)           // Skip `offset` documents
        .limit(limit)   // Limit the number of results
        .populate('supplier')
        .populate('log');
    const total = await Invoices.countDocuments();
    res.status(200).json({
        success: true,
        invoices,
        pages: Math.ceil(total / limit)
    });
});

exports.getInvoicesBySupplier = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const supplierId = req.query.supplierId;
    const offset = (page - 1) * limit;

    if (!supplierId) {
        return res.status(400).json({
            success: false,
            message: 'Supplier ID is required'
        });
    }

    const invoices = await Invoices.find({ supplier: supplierId })
        .sort({ addedAt: -1 })
        .skip(offset)
        .limit(limit)
        .populate('supplier')
        .populate('log');
    
    const total = await Invoices.countDocuments({ supplier: supplierId });
    
    res.status(200).json({
        success: true,
        invoices,
        pages: Math.ceil(total / limit)
    });
});

exports.getAllLogs = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const offset = (page - 1) * limit;
    const includeSuperseded = req.query.includeSuperseded === 'true';

    // Build query - exclude superseded logs unless explicitly requested
    const query = includeSuperseded ? {} : { isSuperseded: { $ne: true } };

    const logs = await Logs.find(query)
        .sort({ addedAt: -1 })  // Sort ascending
        .skip(offset)           // Skip `offset` documents
        .limit(limit)   // Limit the number of results
        .populate('supplier');
    const total = await Logs.countDocuments(query);
    res.status(200).json({
        success: true,
        logs,
        pages: Math.ceil(total / limit)
    });
});

exports.getSuppliers = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const search = req.query.search || '';
    const offset = (page - 1) * limit;

    const matchStage = search
        ? { name: { $regex: search, $options: 'i' } }
        : {};

    const suppliers = await Suppliers.aggregate([
        { $match: matchStage },

        // Join invoices
        {
            $lookup: {
                from: 'invoices',          // collection name (plural, lowercase)
                localField: '_id',
                foreignField: 'supplier',  // field in invoices
                as: 'invoices'
            }
        },

        // Count invoices
        {
            $addFields: {
                invoiceCount: { $size: '$invoices' }
            }
        },

        // Sort A → Z
        { $sort: { name: 1 } },

        // Pagination
        { $skip: offset },
        { $limit: limit },

        // Optional: remove invoice array from response
        {
            $project: {
                invoices: 0
            }
        }
    ]);

    const total = await Suppliers.countDocuments(matchStage);

    res.status(200).json({
        success: true,
        suppliers,
        pages: Math.ceil(total / limit)
    });
});


exports.getLogs = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const id = req.query.id;
    const offset = (page - 1) * limit;

    // Exclude superseded logs from supplier logs view
    const logs = await Logs.find({ 
        supplier: id,
        isSuperseded: { $ne: true }
    })
        .sort({ addedAt: -1 })  // Sort ascending
        .skip(offset)           // Skip `offset` documents
        .limit(limit);          // Limit the number of results

    const total = await Logs.countDocuments({ 
        supplier: id,
        isSuperseded: { $ne: true }
    });

    res.status(200).json({
        success: true,
        logs,
        pages: Math.ceil(total / limit)
    });
});

exports.getNewerLog = tryCatchAsync(async (req, res) => {
    const logId = req.query.logId;
    
    if (!logId) {
        return res.status(400).json({
            success: false,
            message: 'Log ID is required'
        });
    }

    // Find the log
    const log = await Logs.findById(logId).populate('supplier');
    
    if (!log) {
        return res.status(404).json({
            success: false,
            message: 'Log not found'
        });
    }

    // If log is not superseded, return it
    if (!log.isSuperseded) {
        return res.status(200).json({
            success: true,
            logId: log._id
        });
    }

    // Find the newer log with same supplier and invoiceIssueDate
    if (log.supplier && log.invoiceIssueDate) {
        // Normalize date to compare only date part (without time)
        const normalizedDate = new Date(log.invoiceIssueDate);
        normalizedDate.setHours(0, 0, 0, 0);
        const nextDay = new Date(normalizedDate);
        nextDay.setDate(nextDay.getDate() + 1);

        const newerLog = await Logs.findOne({
            supplier: log.supplier._id || log.supplier,
            invoiceIssueDate: {
                $gte: normalizedDate,
                $lt: nextDay
            },
            _id: { $ne: log._id },
            addedAt: { $gt: log.addedAt },
            isSuperseded: { $ne: true }
        }).sort({ addedAt: -1 }); // Get the most recent one

        if (newerLog) {
            return res.status(200).json({
                success: true,
                logId: newerLog._id
            });
        }
    }

    // If no newer log found, return the original log ID
    return res.status(200).json({
        success: true,
        logId: log._id
    });
});

/**
 * Parse invoices from PDF or Excel files and return them
 * This route only parses files and returns invoice data without saving to database
 */
exports.parseInvoices = tryCatchAsync(async (req, res) => {
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/2c1ebcd6-def4-40f4-961d-27e83d539bc4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'InvoiceController.js:509',message:'parseInvoices entry',data:{hasFile:!!req.file,fileName:req.file?.originalname,fileSize:req.file?.size,fileMimetype:req.file?.mimetype},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'D'})}).catch(()=>{});
    // #endregion
    
    if (!req.file) {
        return res.status(400).json({
            success: false,
            message: 'No file uploaded'
        });
    }

    const fileBuffer = req.file.buffer;
    const fileName = req.file.originalname || 'unknown';
    
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/2c1ebcd6-def4-40f4-961d-27e83d539bc4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'InvoiceController.js:518',message:'file buffer created',data:{bufferSize:fileBuffer.length,fileName:fileName},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'D'})}).catch(()=>{});
    // #endregion

    // Helper function for logging (only in development)
    const isDevelopment = process.env.NODE_ENV !== 'production';
    function log(...args) {
        if (isDevelopment) {
            console.log(...args);
        }
    }

    // Helper function for retry logic with error context passing
    async function retryWithBackoff(logic, maxAttempts = 3, errorMessage = 'Operation failed', getErrorContext = null) {
        let attempts = 0;
        let lastError;
        let errorContext = null;

        while (attempts < maxAttempts) {
            attempts++;
            try {
                // Pass error context to logic function if available
                return await logic(errorContext);
            } catch (err) {
                lastError = err;
                log(`Attempt ${attempts} failed:`, err.message);
                
                // Get error context for next attempt if function provided
                if (getErrorContext && attempts < maxAttempts) {
                    errorContext = getErrorContext(err);
                    log(`   - Retrying with error context: ${errorContext}`);
                }
                
                if (attempts < maxAttempts) {
                    await new Promise(resolve => setTimeout(resolve, 1000 * attempts));
                }
            }
        }

        throw new Error(`${errorMessage} after ${maxAttempts} attempts: ${lastError?.message || 'Unknown error'}`);
    }

    // Helper function to parse AI response
    function parseAIResponse(format, source) {
        // Clean up the response - remove markdown code blocks if present
        let cleanedFormat = format.replace(/```json/gi, '').replace(/```/gi, '').trim();
        
        // Try to parse JSON
        let invoicesObj;
        try {
            invoicesObj = JSON.parse(cleanedFormat);
        } catch (parseError) {
            // If parsing fails, try to extract JSON from the response
            const jsonMatch = cleanedFormat.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                invoicesObj = JSON.parse(jsonMatch[0]);
            } else {
                throw new Error(`Unable to extract valid JSON from ${source} AI response`);
            }
        }

        // Validate structure
        if (!invoicesObj || !invoicesObj.invoices || !Array.isArray(invoicesObj.invoices)) {
            throw new Error(`Invalid invoice structure returned from ${source} AI`);
        }

        // Process invoices and ensure each has a unique invoice number
        const processedInvoices = invoicesObj.invoices.map((inv, index) => ({
            invoiceDate: inv.invoiceDate || null,
            invoiceNumber: inv.invoiceNumber || null,
            activityDescription: inv.activityDescription || null,
            amount: {
                amount: typeof inv.amount?.amount === 'number' ? inv.amount.amount : 
                       typeof inv.amount === 'number' ? inv.amount : null,
                tax_fees: typeof inv.amount?.tax_fees === 'number' ? inv.amount.tax_fees : 
                         typeof inv.amount?.tax === 'number' ? inv.amount.tax : 0
            },
            currency: inv.currency || null,
            paymentStatus: inv.paymentStatus || null
        }));

        // Validate unique invoice numbers
        const invoiceNumberMap = new Map();
        const duplicates = [];
        processedInvoices.forEach((inv, index) => {
            const invNum = inv.invoiceNumber;
            if (invNum) {
                if (invoiceNumberMap.has(invNum)) {
                    duplicates.push({
                        invoiceNumber: invNum,
                        indices: [invoiceNumberMap.get(invNum), index]
                    });
                } else {
                    invoiceNumberMap.set(invNum, index);
                }
            }
        });

        // If duplicates found, throw error to trigger retry
        if (duplicates.length > 0) {
            const duplicateDetails = duplicates.map(dup => 
                `"${dup.invoiceNumber}" at indices ${dup.indices.join(', ')}`
            ).join('; ');
            throw new Error(`Duplicate invoice numbers found: ${duplicateDetails}. Each invoice must have a unique invoice number. If the file contains only one invoice, return an array with ONE invoice object.`);
        }

        return {
            fileDate: invoicesObj.fileDate || null,
            invoices: processedInvoices
        };
    }

    // Save file to disk
    let newFileName;
    function saveFile(fileBuffer, fileName) {
        const folderPath = path.join(__dirname, "../media/files");
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
        }

        const fileExtension = path.extname(fileName) || '.pdf';
        const uniqueName = uuidv4() + fileExtension;
        const savePath = path.join(folderPath, uniqueName);
        fs.writeFileSync(savePath, fileBuffer);
        newFileName = uniqueName;
        return uniqueName;
    }

    // Parse file based on type
    async function parseFile(fileBuffer, fileName) {
        const fileType = await fileTypeFromBuffer(fileBuffer);
        
        if (!fileType) {
            throw new Error('Unable to determine file type');
        }

        if (fileType.ext === 'xlsx' || fileType.ext === 'xls') {
            // Parse Excel file from buffer
            const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
            const allRecords = [];

            workbook.SheetNames.forEach(sheetName => {
                const sheet = workbook.Sheets[sheetName];
                const records = XLSX.utils.sheet_to_json(sheet, { 
                    defval: null,
                    raw: false, // Convert all values to strings for better AI processing
                    dateNF: 'yyyy-mm-dd' // Date format
                });
                records.forEach(r => {
                    r.sheetName = sheetName;
                    r._source = 'excel';
                });
                allRecords.push(...records);
            });

            return {
                type: 'excel',
                data: allRecords,
                raw: JSON.stringify(allRecords, null, 2)
            };
        } else if (fileType.ext === 'pdf') {
            // Parse PDF file from buffer
            const parser = new PDFParse({ data: fileBuffer });
            const fileData = await parser.getText();
            if (parser.destroy) {
                await parser.destroy();
            }

            return {
                type: 'pdf',
                data: fileData.text,
                raw: fileData.text
            };
        } else {
            throw new Error(`Unsupported file type: ${fileType.ext}. Only PDF and Excel files are supported.`);
        }
    }

    // Helper function to convert fileDate to valid Date
    function toValidDate(value) {
        if (!value) return null;
        const date = new Date(value);
        return isNaN(date.getTime()) ? null : date;
    }

    // Enhanced company name extraction and variation generation
    function generateCompanyVariations(companyName) {
        if (!companyName || companyName.trim().length === 0) {
            return [];
        }

        const variations = new Set();
        const cleanName = companyName.trim();

        // Add original
        variations.add(cleanName);

        // Remove common suffixes and add variations
        const suffixes = ['ltd', 'limited', 'llc', 'inc', 'incorporated', 'corp', 'corporation', 'plc', 'pty', 'pty ltd'];
        let baseName = cleanName;
        for (const suffix of suffixes) {
            const regex = new RegExp(`\\s+${suffix}\\.?$`, 'i');
            if (regex.test(baseName)) {
                baseName = baseName.replace(regex, '').trim();
                variations.add(baseName);
                variations.add(`${baseName} ${suffix}`);
                variations.add(`${baseName} ${suffix}.`);
            }
        }

        // Split into words and create variations
        const words = cleanName.replace(/[^a-zA-Z0-9\s]/g, '').split(/\s+/).filter(w => w.length > 0);
        
        if (words.length > 0) {
            // All words
            variations.add(words.join(' '));
            variations.add(words.join('').toLowerCase());
            
            // Case variations
            variations.add(words.map(w => w.toLowerCase()).join(' '));
            variations.add(words.map(w => w.toUpperCase()).join(' '));
            variations.add(words.map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' '));
            
            // Individual words (for partial matching)
            words.forEach(word => {
                if (word.length > 2) {
                    variations.add(word.toLowerCase());
                    variations.add(word.toUpperCase());
                    variations.add(word.charAt(0).toUpperCase() + word.slice(1).toLowerCase());
                }
            });

            // First word + last word (common pattern)
            if (words.length > 1) {
                variations.add(`${words[0]} ${words[words.length - 1]}`);
            }
        }

        return Array.from(variations).filter(v => v.length > 0);
    }

    // Extract company name from document
    async function extractCompanyName(fileName, content) {
        const email = ''; // Can be extracted from request if available
        const contentPreview = typeof content === 'string' 
            ? content.substring(0, 3000) 
            : JSON.stringify(content).substring(0, 3000);
        
        const companyName = await retryWithBackoff(async () => {
            const name = await findMatchingCompanyWithAI(email, fileName, contentPreview);
            return name && name.trim().length > 0 ? name.trim() : null;
        }, 3, 'Failed to extract company name');

        return companyName;
    }

    // Find matching Xero contact (if Xero credentials available)
    async function findXeroContact(companyName, fileName, accessToken, tenantId) {
        if (!accessToken || !tenantId || !companyName) {
            return null;
        }

        try {
            const variations = generateCompanyVariations(companyName);
            const searchTerms = variations
                .filter(term => term.trim().length > 0 && term.length > 2)
                .slice(0, 20); // Limit to avoid URL length issues

            if (searchTerms.length === 0) {
                return null;
            }

            // Build Xero query
            const filter = searchTerms
                .map(term => `Name.Contains("${encodeURIComponent(term)}")`)
                .join(" OR ");

            const url = `https://api.xero.com/api.xro/2.0/Contacts?where=${filter}`;
            const response = await axios.get(url, {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    'Xero-tenant-id': tenantId,
                    Accept: 'application/json'
                },
                timeout: 10000
            });

            const allContacts = response?.data?.Contacts || [];
            const contactsWithBalance = allContacts.filter(ct => ct.Balances);

            if (contactsWithBalance.length === 0) {
                log(`   - Found ${allContacts.length} contacts but none with balances`);
                return null;
            }

            // Use AI to find best match
            const bestMatch = await retryWithBackoff(async () => {
                const matchResult = await findMatchingCompanyWithAIFromAList(
                    companyName, 
                    fileName, 
                    '', 
                    contactsWithBalance
                );
                
                const cleaned = matchResult.replace(/```json/gi, '').replace(/```/gi, '').trim();
                const matchData = JSON.parse(cleaned);
                
                // Validate GUID format
                const isXeroContactId = (id) =>
                    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
                
                if (!isXeroContactId(matchData.id)) {
                    throw new Error("Invalid contact ID format");
                }
                
                return {
                    contactId: matchData.id,
                    contact: contactsWithBalance.find(ct => ct.ContactID === matchData.id)
                };
            }, 3, 'Failed to match company with Xero contact');

            return bestMatch;
        } catch (error) {
            log(`   - Xero contact search failed: ${error.message}`);
            return null;
        }
    }

    // Save file first
    saveFile(fileBuffer, fileName);
    
    // Create log entry
    const invoiceIssueDate = null; // Will be set after parsing
    let logDoc;
    let companyInfo = null;
    let supplierInfo = null;
    
    try {
        // Parse the file
        const parsedData = await parseFile(fileBuffer, fileName);
        log('\n=== PARSING FILE ===');
        log(`File: ${fileName}`);
        log(`Saved as: ${newFileName}`);
        log(`Type: ${parsedData.type}`);
        log(`Data length: ${parsedData.raw.length} characters\n`);

        // Check if file has multiple invoice numbers
        log('=== CHECKING INVOICE COUNT ===');
        const invoiceCountCheck = await retryWithBackoff(
            async () => {
                // Use a preview of the content for the check (first 5000 characters should be enough)
                const contentPreview = typeof parsedData.raw === 'string' 
                    ? parsedData.raw.substring(0, 5000) 
                    : JSON.stringify(parsedData.raw).substring(0, 5000);
                return await checkMultipleInvoiceNumbers(contentPreview, fileName);
            },
            3,
            'Failed to check invoice count'
        );
        
        log(`✅ Invoice Count Check:`);
        log(`   - Has Multiple Invoices: ${invoiceCountCheck.hasMultipleInvoices}`);
        log(`   - Invoice Count: ${invoiceCountCheck.invoiceCount || 'Unknown'}`);
        log(`   - Reason: ${invoiceCountCheck.reason}\n`);

        // Extract company name
        log('=== EXTRACTING COMPANY NAME ===');
        const companyName = await extractCompanyName(fileName, parsedData.raw);
        
        if (companyName) {
            log(`✅ Company Name: ${companyName}`);
            companyInfo = { name: companyName };
            
            // Find matching Xero contact (credentials are required via middleware)
            const accessToken = req.xeroAccessToken;
            const tenantId = req.xeroTenantId;
            
            log('=== SEARCHING XERO CONTACTS ===');
            const xeroMatch = await findXeroContact(companyName, fileName, accessToken, tenantId);
            
            if (xeroMatch) {
                log(`✅ Found Xero Contact: ${xeroMatch.contact.Name} (${xeroMatch.contactId})`);
                companyInfo.xeroContactId = xeroMatch.contactId;
                companyInfo.xeroContactName = xeroMatch.contact.Name;
                
                // Find or create supplier
                supplierInfo = await Suppliers.findOne({ xeroId: xeroMatch.contactId });
                if (!supplierInfo) {
                    supplierInfo = await Suppliers.create({ 
                        xeroId: xeroMatch.contactId, 
                        name: xeroMatch.contact.Name 
                    });
                    log(`✅ Created new supplier: ${supplierInfo.name}`);
                } else {
                    log(`✅ Found existing supplier: ${supplierInfo.name}`);
                }
            } else {
                log('⚠️  No matching Xero contact found');
            }
        } else {
            log('⚠️  Could not extract company name');
        }

        // Format data with AI to extract invoices
        log('\n=== EXTRACTING INVOICES ===');
        if (invoiceCountCheck.hasMultipleInvoices === true) {
            log(`   - File contains MULTIPLE invoices - will extract each row separately`);
        } else if (invoiceCountCheck.hasMultipleInvoices === false) {
            log(`   - File contains SINGLE invoice - will extract from header/title`);
        }
        const formattedInvoices = await retryWithBackoff(
            async (errorContext) => {
                const format = await formatWithAIToStandardJSON(parsedData.raw, fileName, errorContext, invoiceCountCheck);
                return parseAIResponse(format, 'AI');
            }, 
            3, 
            'Failed to format invoices with AI',
            // Function to extract error context from the error
            (err) => {
                // If error message contains duplicate information, pass it to AI
                if (err.message && err.message.includes('Duplicate invoice numbers')) {
                    return err.message;
                }
                return null;
            }
        );

        // Get file date and create log
        const fileDate = toValidDate(formattedInvoices.fileDate);
        logDoc = await Logs.create({ 
            status: 'started', 
            file: newFileName, 
            invoiceIssueDate: fileDate,
            supplier: supplierInfo?._id || undefined
        });

        log('✅ AI Extraction Success:');
        log(`   - File Date: ${formattedInvoices.fileDate}`);
        log(`   - Invoice Count: ${formattedInvoices.invoices.length}`);
        if (formattedInvoices.invoices.length > 0) {
            log(`   - Sample Invoice Numbers: ${formattedInvoices.invoices.slice(0, 5).map(i => i.invoiceNumber).filter(Boolean).join(', ')}`);
        }

        // Get invoices from Xero if supplier was found
        let xeroInvoices = [];
        if (supplierInfo && companyInfo?.xeroContactId) {
            log('\n=== FETCHING INVOICES FROM XERO ===');
            try {
                const accessToken = req.xeroAccessToken;
                const tenantId = req.xeroTenantId;
                const contactId = companyInfo.xeroContactId;

                // Get invoices from Xero using same logic as parseFiles
                async function getInvoicesFromXero() {
                    // Get file issue date
                    const fileIssueDate = fileDate ? new Date(fileDate) : null;
                    
                    // Get last invoice date from database (last check date)
                    const lastInvoiceFromSupplier = await Invoices.findOne({ supplier: supplierInfo._id }).sort({ createdAt: -1 });
                    const lastCheckDate = lastInvoiceFromSupplier?.addedAt ? new Date(lastInvoiceFromSupplier.addedAt) : null;
                    
                    // Use the earlier of the two dates, or default to 19 months ago if neither exists
                    let fromDateObj;
                    if (fileIssueDate && lastCheckDate) {
                        fromDateObj = fileIssueDate < lastCheckDate ? fileIssueDate : lastCheckDate;
                        log(`   - File issue date: ${fileIssueDate.toISOString().split('T')[0]}`);
                        log(`   - Last check date: ${lastCheckDate.toISOString().split('T')[0]}`);
                        log(`   - Using earlier date: ${fromDateObj.toISOString().split('T')[0]}`);
                    } else if (fileIssueDate) {
                        fromDateObj = fileIssueDate;
                        log(`   - Using file issue date: ${fromDateObj.toISOString().split('T')[0]}`);
                    } else if (lastCheckDate) {
                        fromDateObj = lastCheckDate;
                        log(`   - Using last check date: ${fromDateObj.toISOString().split('T')[0]}`);
                    } else {
                        // Default fallback: 19 months ago
                        const today = new Date();
                        fromDateObj = new Date(today);
                        fromDateObj.setMonth(today.getMonth() - 19);
                        log(`   - No file or check date found, using default: ${fromDateObj.toISOString().split('T')[0]}`);
                    }
                    
                    const fromDate = `${fromDateObj.getFullYear()},${String(fromDateObj.getMonth() + 1).padStart(2, '0')},${String(fromDateObj.getDate()).padStart(2, '0')}`;
                    
                    const where = `
                        Contact.ContactID == Guid("${contactId}")
                        AND Date >= DateTime(${fromDate})`;

                    log(`   - Xero query: ${where}`);
      
                    const invoiceUrl = `https://api.xero.com/api.xro/2.0/Invoices?where=${encodeURIComponent(where)}`;
                    const invoiceResponse = await axios.get(invoiceUrl, {
                        headers: {
                            Authorization: `Bearer ${accessToken}`,
                            'Xero-tenant-id': tenantId,
                            Accept: 'application/json',
                        },
                    });

                    return invoiceResponse.data.Invoices || [];
                }

                const invoicesArray = await getInvoicesFromXero();
                
                // Format Xero invoices to match file invoice format
                // Preserve original invoice numbers - they should be unique per record
                xeroInvoices = invoicesArray.map(inv => {
                    return {
                        invoiceDate: new Date(inv.DateString).toLocaleDateString('en-GB'),
                        invoiceNumber: inv.InvoiceNumber || null, // Keep original invoice number
                        activityDescription: inv.LineItems?.[0]?.Description || null,
                        amount: {
                            amount: inv.SubTotal || 0,
                            tax_fees: inv.TotalTax || 0
                        },
                        currency: inv.CurrencyCode === 'USD' ? '$' : 
                                 inv.CurrencyCode === 'GBP' ? '£' : 
                                 inv.CurrencyCode === 'EUR' ? '€' : 
                                 inv.CurrencyCode || '$',
                        paymentStatus: inv.Status === 'AUTHORISED' ? 'unpaid' : 'paid',
                    };
                });

                log(`✅ Found ${xeroInvoices.length} invoices from Xero`);
                if (xeroInvoices.length > 0) {
                    log(`   - Sample Invoice Numbers: ${xeroInvoices.slice(0, 5).map(i => i.invoiceNumber).filter(Boolean).join(', ')}`);
                }
            } catch (xeroError) {
                log(`⚠️  Failed to fetch Xero invoices: ${xeroError.message}`);
            }
        } else {
            log('⚠️  Skipping Xero invoice fetch - no supplier or contact ID');
        }

        // Match invoices from file and Xero
        function normalizeInvoiceNumber(invoiceNumber) {
            if (!invoiceNumber) return '';
            // Remove all non-digit characters for comparison
            return invoiceNumber.toString().replace(/\D/g, '');
        }

        function getInvoiceNumberVariations(invoiceNumber) {
            if (!invoiceNumber) return new Set();
            const variations = new Set();
            const normalized = invoiceNumber.toString().trim();
            
            // Original
            variations.add(normalized);
            
            // Lowercase
            variations.add(normalized.toLowerCase());
            
            // Uppercase
            variations.add(normalized.toUpperCase());
            
            // Digits only (normalized)
            const digitsOnly = normalizeInvoiceNumber(normalized);
            if (digitsOnly) {
                variations.add(digitsOnly);
            }
            
            // Remove common prefixes/suffixes and get digits
            const withoutPrefix = normalized.replace(/^(INV|INVOICE|REF|REFERENCE|DOC|DOCUMENT|#|NO|NUMBER)[\s\-_]*/i, '');
            if (withoutPrefix !== normalized) {
                variations.add(withoutPrefix);
                variations.add(normalizeInvoiceNumber(withoutPrefix));
            }
            
            // Remove common suffixes
            const withoutSuffix = normalized.replace(/[\s\-_]*(INV|INVOICE|REF|REFERENCE|DOC|DOCUMENT)?$/i, '');
            if (withoutSuffix !== normalized) {
                variations.add(withoutSuffix);
                variations.add(normalizeInvoiceNumber(withoutSuffix));
            }
            
            return variations;
        }

        function matchInvoices(fileInvoices, xeroInvoices) {
            const matched = [];
            const unmatchedFile = [];
            const unmatchedXero = [];
            
            // Create maps with all variations as keys - store index for tracking
            const xeroMap = new Map(); // variation -> [indices]
            const xeroInvoicesWithIndex = xeroInvoices.map((inv, idx) => ({ ...inv, _index: idx }));
            const fileInvoicesWithIndex = fileInvoices.map((inv, idx) => ({ ...inv, _index: idx }));
            
            // Index Xero invoices by all variations
            xeroInvoicesWithIndex.forEach(xeroInv => {
                const originalNumber = xeroInv.invoiceNumber || '';
                const variations = getInvoiceNumberVariations(originalNumber);
                variations.forEach(variation => {
                    if (variation) {
                        if (!xeroMap.has(variation)) {
                            xeroMap.set(variation, []);
                        }
                        xeroMap.get(variation).push(xeroInv);
                    }
                });
            });
            
            // Track which invoices have been matched by index
            const matchedXeroIndices = new Set();
            const matchedFileIndices = new Set();
            
            // Helper function to parse date string to Date object
            function parseDate(dateStr) {
                if (!dateStr) return null;
                try {
                    // Handle dd/mm/yyyy format
                    if (dateStr.includes('/')) {
                        const parts = dateStr.split('/');
                        if (parts.length === 3) {
                            const day = parseInt(parts[0], 10);
                            const month = parseInt(parts[1], 10) - 1;
                            const year = parseInt(parts[2], 10);
                            const date = new Date(year, month, day);
                            if (!isNaN(date.getTime())) return date;
                        }
                    }
                    // Try standard Date parsing
                    const date = new Date(dateStr);
                    if (!isNaN(date.getTime())) return date;
                } catch (e) {
                    // Invalid date
                }
                return null;
            }
            
            // Helper function to check if two dates are within a window
            function datesWithinWindow(date1, date2, daysWindow = 7) {
                if (!date1 || !date2) return false;
                const diffMs = Math.abs(date1.getTime() - date2.getTime());
                const diffDays = diffMs / (1000 * 60 * 60 * 24);
                return diffDays <= daysWindow;
            }
            
            // Helper function to check if two amounts match (with tolerance)
            function amountsMatch(amount1, amount2, tolerance = 0.01) {
                if (amount1 == null || amount2 == null) return false;
                const diff = Math.abs(amount1 - amount2);
                return diff <= tolerance;
            }
            
            // STEP 1: Match by Reference ID (invoice number) - STRONG MATCH
            fileInvoicesWithIndex.forEach((fileInv) => {
                const fileNumber = fileInv.invoiceNumber || '';
                const fileVariations = getInvoiceNumberVariations(fileNumber);
                
                let foundMatch = false;
                // Try variations in order of specificity (most specific first)
                const sortedVariations = Array.from(fileVariations).sort((a, b) => {
                    // Prefer exact matches, then normalized, then digits-only
                    if (a === fileNumber) return -1;
                    if (b === fileNumber) return 1;
                    const aDigits = normalizeInvoiceNumber(a);
                    const bDigits = normalizeInvoiceNumber(b);
                    if (aDigits === fileNumber.replace(/\D/g, '')) return -1;
                    if (bDigits === fileNumber.replace(/\D/g, '')) return 1;
                    return b.length - a.length; // Longer matches are more specific
                });
                
                for (const variation of sortedVariations) {
                    if (xeroMap.has(variation)) {
                        const matchingXero = xeroMap.get(variation);
                        // Find first unmatched Xero invoice
                        const xeroMatch = matchingXero.find(x => !matchedXeroIndices.has(x._index));
                        
                        if (xeroMatch && !matchedXeroIndices.has(xeroMatch._index)) {
                            // Remove _index before adding to result
                            const { _index: fileIdx, ...fileInvClean } = fileInv;
                            const { _index: xeroIdx, ...xeroInvClean } = xeroMatch;
                            
                            matched.push({
                                fileInvoice: fileInvClean,
                                xeroInvoice: xeroInvClean,
                                matchKey: variation,
                                matchType: 'referenceId',
                                fileInvoiceNumber: fileNumber,
                                xeroInvoiceNumber: xeroMatch.invoiceNumber || ''
                            });
                            matchedXeroIndices.add(xeroMatch._index);
                            matchedFileIndices.add(fileInv._index);
                            foundMatch = true;
                            break;
                        }
                    }
                }
                
                if (!foundMatch) {
                    const { _index, ...fileInvClean } = fileInv;
                    unmatchedFile.push(fileInvClean);
                }
            });
            
            // STEP 2: Fallback heuristic matching for unmatched invoices
            // Match using date ± window + amount (for invoices not matched by Reference ID)
            const remainingUnmatchedFile = fileInvoicesWithIndex.filter(
                inv => !matchedFileIndices.has(inv._index)
            );
            const remainingUnmatchedXero = xeroInvoicesWithIndex.filter(
                inv => !matchedXeroIndices.has(inv._index)
            );
            
            // Try to match remaining file invoices with remaining Xero invoices
            remainingUnmatchedFile.forEach((fileInv) => {
                if (matchedFileIndices.has(fileInv._index)) return; // Already matched
                
                const fileDate = parseDate(fileInv.invoiceDate);
                const fileAmount = fileInv.amount?.amount;
                
                // Skip if we don't have both date and amount for heuristic matching
                if (!fileDate || fileAmount == null) return;
                
                // Find best match from unmatched Xero invoices
                let bestMatch = null;
                let bestMatchIndex = -1;
                
                remainingUnmatchedXero.forEach((xeroInv, xeroIdx) => {
                    if (matchedXeroIndices.has(xeroInv._index)) return; // Already matched
                    
                    const xeroDate = parseDate(xeroInv.invoiceDate);
                    const xeroAmount = xeroInv.amount?.amount;
                    
                    // Skip if we don't have both date and amount
                    if (!xeroDate || xeroAmount == null) return;
                    
                    // Check if dates are within window (default ±7 days)
                    const dateMatch = datesWithinWindow(fileDate, xeroDate, 7);
                    // Check if amounts match (default tolerance ±0.01)
                    const amountMatch = amountsMatch(fileAmount, xeroAmount, 0.01);
                    
                    // Both date and amount must match for heuristic match
                    if (dateMatch && amountMatch) {
                        bestMatch = xeroInv;
                        bestMatchIndex = xeroInv._index;
                    }
                });
                
                // If we found a heuristic match, add it
                if (bestMatch && bestMatchIndex !== -1) {
                    const { _index: fileIdxToRemove, ...fileInvClean } = fileInv;
                    const { _index: xeroIdxToRemove, ...xeroInvClean } = bestMatch;
                    
                    matched.push({
                        fileInvoice: fileInvClean,
                        xeroInvoice: xeroInvClean,
                        matchKey: `date+amount`,
                        matchType: 'heuristic',
                        fileInvoiceNumber: fileInv.invoiceNumber || '',
                        xeroInvoiceNumber: bestMatch.invoiceNumber || ''
                    });
                    matchedXeroIndices.add(bestMatchIndex);
                    matchedFileIndices.add(fileInv._index);
                    
                    // Remove from unmatched arrays
                    const unmatchedFileIdx = unmatchedFile.findIndex(inv => 
                        (inv.invoiceNumber || '') === (fileInv.invoiceNumber || '') &&
                        (inv.invoiceDate || '') === (fileInv.invoiceDate || '')
                    );
                    if (unmatchedFileIdx !== -1) unmatchedFile.splice(unmatchedFileIdx, 1);
                }
            });
            
            // Collect all unmatched Xero invoices (those not matched in either step)
            xeroInvoicesWithIndex.forEach((xeroInv) => {
                if (!matchedXeroIndices.has(xeroInv._index)) {
                    const { _index, ...xeroInvClean } = xeroInv;
                    unmatchedXero.push(xeroInvClean);
                }
            });
            
            return {
                matched,
                unmatchedFile,
                unmatchedXero,
                matchCount: matched.length,
                unmatchedFileCount: unmatchedFile.length,
                unmatchedXeroCount: unmatchedXero.length
            };
        }

        // Perform matching
        const matchingResults = matchInvoices(formattedInvoices.invoices, xeroInvoices);
        
        log('\n=== INVOICE MATCHING RESULTS ===');
        log(`✅ Matched: ${matchingResults.matchCount} invoices`);
        
        // Count matches by type
        const referenceIdMatches = matchingResults.matched.filter(m => m.matchType === 'referenceId').length;
        const heuristicMatches = matchingResults.matched.filter(m => m.matchType === 'heuristic').length;
        
        if (referenceIdMatches > 0) {
            log(`   - Reference ID matches (strong): ${referenceIdMatches}`);
        }
        if (heuristicMatches > 0) {
            log(`   - Heuristic matches (date + amount): ${heuristicMatches}`);
        }
        
        log(`⚠️  Unmatched from file: ${matchingResults.unmatchedFileCount}`);
        log(`⚠️  Unmatched from Xero: ${matchingResults.unmatchedXeroCount}`);
        
        if (matchingResults.matched.length > 0) {
            log(`   - Sample matches:`);
            matchingResults.matched.slice(0, 5).forEach(m => {
                const matchTypeLabel = m.matchType === 'referenceId' ? 'Reference ID' : 'Heuristic (date+amount)';
                log(`     File: "${m.fileInvoiceNumber}" ↔ Xero: "${m.xeroInvoiceNumber}" (${matchTypeLabel})`);
            });
        }

        // Save all invoices to database if supplier exists
        if (supplierInfo && supplierInfo._id) {
            log('\n=== SAVING INVOICES TO DATABASE ===');
            
            // Helper function to convert date string to Date object
            function parseDate(dateStr) {
                if (!dateStr) return null;
                try {
                    // Handle dd/mm/yyyy format
                    if (dateStr.includes('/')) {
                        const parts = dateStr.split('/');
                        if (parts.length === 3) {
                            const day = parseInt(parts[0], 10);
                            const month = parseInt(parts[1], 10) - 1;
                            const year = parseInt(parts[2], 10);
                            const date = new Date(year, month, day);
                            if (!isNaN(date.getTime())) return date;
                        }
                    }
                    // Try standard Date parsing
                    const date = new Date(dateStr);
                    if (!isNaN(date.getTime())) return date;
                } catch (e) {
                    // Invalid date
                }
                return null;
            }

            // Helper function to normalize invoice number for comparison
            function normalizeInvoiceNumberForDB(invoiceNumber) {
                if (!invoiceNumber) return '';
                return invoiceNumber.toString().trim().replace(/\D/g, '');
            }

            // Helper function to find existing invoice by number (for same supplier)
            async function findExistingInvoice(invoiceNumber, supplierId) {
                if (!invoiceNumber) return null;
                
                const normalized = normalizeInvoiceNumberForDB(invoiceNumber);
                if (!normalized) return null;
                
                // First try exact match
                const exactMatch = await Invoices.findOne({ 
                    supplier: supplierId,
                    invoiceNumber: invoiceNumber
                });
                if (exactMatch) return exactMatch;
                
                // Then try normalized match - get all invoices for this supplier and compare normalized numbers
                const allInvoices = await Invoices.find({ 
                    supplier: supplierId,
                    invoiceNumber: { $exists: true, $ne: null }
                });
                
                for (const inv of allInvoices) {
                    if (inv.invoiceNumber) {
                        const invNormalized = normalizeInvoiceNumberForDB(inv.invoiceNumber);
                        if (invNormalized === normalized) {
                            return inv;
                        }
                    }
                }
                
                return null;
            }

            // Save matched invoices
            let updatedCount = 0;
            let createdCount = 0;
            
            for (const match of matchingResults.matched) {
                const fileInv = match.fileInvoice;
                const xeroInv = match.xeroInvoice;
                const invoiceNumber = fileInv ? fileInv.invoiceNumber : (xeroInv ? xeroInv.invoiceNumber : null);
                
                if (!invoiceNumber) {
                    log(`   ⚠️  Skipping invoice without invoice number`);
                    continue;
                }
                
                // Check if invoice already exists
                const existingInvoice = await findExistingInvoice(invoiceNumber, supplierInfo._id);
                
                const invoiceData = {
                    invoiceDate: fileInv ? parseDate(fileInv.invoiceDate) : null,
                    invoiceXeroDate: xeroInv ? parseDate(xeroInv.invoiceDate) : null,
                    invoiceNumber: invoiceNumber,
                    activityDescription: fileInv ? fileInv.activityDescription : null,
                    amountXero: xeroInv ? { 
                        amount: xeroInv.amount?.amount ?? 0, 
                        taxFees: xeroInv.amount?.tax_fees ?? 0 
                    } : null,
                    amount: fileInv ? { 
                        amount: fileInv.amount?.amount ?? 0, 
                        taxFees: fileInv.amount?.tax_fees ?? 0 
                    } : null,
                    currency: fileInv ? fileInv.currency : (xeroInv ? xeroInv.currency : null),
                    paymentStatus: fileInv ? fileInv.paymentStatus : (xeroInv ? xeroInv.paymentStatus : null),
                    supplier: supplierInfo._id,
                    log: logDoc._id
                };
                
                if (existingInvoice) {
                    // Update existing invoice
                    await Invoices.updateOne(
                        { _id: existingInvoice._id },
                        { $set: invoiceData }
                    );
                    updatedCount++;
                    log(`   ✅ Updated existing invoice: ${invoiceNumber}`);
                } else {
                    // Create new invoice
                    await Invoices.create(invoiceData);
                    createdCount++;
                    log(`   ➕ Created new invoice: ${invoiceNumber}`);
                }
            }

            // Save unmatched file invoices (only invoices from file, not unmatched Xero invoices)
            for (const fileInv of matchingResults.unmatchedFile) {
                if (!fileInv.invoiceNumber) {
                    log(`   ⚠️  Skipping invoice without invoice number`);
                    continue;
                }
                
                // Check if invoice already exists
                const existingInvoice = await findExistingInvoice(fileInv.invoiceNumber, supplierInfo._id);
                
                const invoiceData = {
                    invoiceDate: parseDate(fileInv.invoiceDate),
                    invoiceXeroDate: null,
                    invoiceNumber: fileInv.invoiceNumber,
                    activityDescription: fileInv.activityDescription,
                    amountXero: null,
                    amount: fileInv.amount ? { 
                        amount: fileInv.amount.amount ?? 0, 
                        taxFees: fileInv.amount.tax_fees ?? 0 
                    } : null,
                    currency: fileInv.currency,
                    paymentStatus: fileInv.paymentStatus,
                    supplier: supplierInfo._id,
                    log: logDoc._id
                };
                
                if (existingInvoice) {
                    // Update existing invoice
                    await Invoices.updateOne(
                        { _id: existingInvoice._id },
                        { $set: invoiceData }
                    );
                    updatedCount++;
                    log(`   ✅ Updated existing invoice: ${fileInv.invoiceNumber}`);
                } else {
                    // Create new invoice
                    await Invoices.create(invoiceData);
                    createdCount++;
                    log(`   ➕ Created new invoice: ${fileInv.invoiceNumber}`);
                }
            }

            // Note: Unmatched Xero invoices are NOT saved to database
            // Only matched invoices and unmatched file invoices are saved

            const totalProcessed = updatedCount + createdCount;
            log(`✅ Processed ${totalProcessed} invoices to database:`);
            log(`   - Updated existing: ${updatedCount}`);
            log(`   - Created new: ${createdCount}`);
            log(`   - Matched: ${matchingResults.matchCount}`);
            log(`   - Unmatched from file: ${matchingResults.unmatchedFileCount}`);
            log(`   - Unmatched from Xero: ${matchingResults.unmatchedXeroCount} (not saved)`);

            // Update log with completed status
            // unmatched count only includes unmatched file invoices (not unmatched Xero)
            await Logs.updateOne(
                { _id: logDoc._id }, 
                { 
                    status: 'completed', 
                    total: totalProcessed,
                    unmatched: matchingResults.unmatchedFileCount
                }
            );
            
            // Mark older logs as superseded (keep for Activity but hide from other views)
            if (fileDate && supplierInfo?._id) {
                // Normalize date to compare only date part (without time)
                const normalizedDate = new Date(fileDate);
                normalizedDate.setHours(0, 0, 0, 0);
                const nextDay = new Date(normalizedDate);
                nextDay.setDate(nextDay.getDate() + 1);
                
                // Mark older logs as superseded instead of deleting them
                await Logs.updateMany({
                    supplier: supplierInfo._id,
                    invoiceIssueDate: {
                        $gte: normalizedDate,
                        $lt: nextDay
                    },
                    _id: { $ne: logDoc._id }, // Exclude the current log
                    addedAt: { $lt: logDoc.addedAt } // Only older logs
                }, {
                    isSuperseded: true
                });
            }
        } else {
            log('⚠️  Skipping database save - no supplier found');
        }

        // Return the parsed invoices
        res.status(200).json({
            success: true,
            fileName: fileName,
            savedFileName: newFileName,
            fileType: parsedData.type,
            fileDate: formattedInvoices.fileDate,
            invoiceCount: formattedInvoices.invoices.length,
            xeroInvoiceCount: xeroInvoices.length,
            invoiceCountCheck: invoiceCountCheck, // Include the invoice count check result
            logId: logDoc._id,
            company: companyInfo,
            supplier: supplierInfo ? {
                id: supplierInfo._id,
                name: supplierInfo.name,
                xeroId: supplierInfo.xeroId
            } : null,
            invoices: formattedInvoices.invoices,
            xeroInvoices: xeroInvoices,
            matching: {
                matched: matchingResults.matched,
                unmatchedFile: matchingResults.unmatchedFile,
                unmatchedXero: matchingResults.unmatchedXero,
                stats: {
                    totalMatched: matchingResults.matchCount,
                    unmatchedFileCount: matchingResults.unmatchedFileCount,
                    unmatchedXeroCount: matchingResults.unmatchedXeroCount
                }
            },
            savedToDatabase: supplierInfo && supplierInfo._id ? true : false
        });

    } catch (error) {
        // Log error (always log errors, even in production)
        console.error('Error parsing invoices:', {
            message: error.message,
            stack: isDevelopment ? error.stack : undefined,
            fileName: fileName,
            savedFileName: newFileName,
            supplierId: supplierInfo?._id?.toString()
        });
        
        // Update log with failed status if log was created
        if (logDoc && logDoc._id) {
            try {
                await Logs.updateOne({ _id: logDoc._id }, { status: 'failed' });
            } catch (updateError) {
                console.error('Failed to update log status:', updateError.message);
            }
        } else {
            // Create log with failed status if it wasn't created yet
            try {
                await Logs.create({ 
                    status: 'failed', 
                    file: newFileName || fileName,
                    supplier: supplierInfo?._id || undefined
                });
            } catch (logError) {
                console.error('Failed to create error log:', logError.message);
            }
        }

        res.status(500).json({
            success: false,
            message: error.message || 'Failed to parse invoices',
            company: companyInfo,
            supplier: supplierInfo ? {
                id: supplierInfo._id,
                name: supplierInfo.name,
                xeroId: supplierInfo.xeroId
            } : null,
            error: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });
    }
});

exports.test = tryCatchAsync(async (req, res) => {
    const accessToken = req.xeroAccessToken;
    const tenantId = req.xeroTenantId;
    const supplierId = '160c3fba-15f3-43ea-b0cd-fdfa284d976e';

    // Check if Xero credentials are available
    if (!accessToken || !tenantId) {
        return res.status(401).json({
            success: false,
            message: 'Xero authentication required. Missing access token or tenant ID.',
            hasAccessToken: !!accessToken,
            hasTenantId: !!tenantId
        });
    }

    // Get specific invoice by ID
    const invoiceId = 'fbfeb002-39e3-4ec9-af99-fc903c7109ca';
    const invoiceUrl = `https://api.xero.com/api.xro/2.0/Invoices/${invoiceId}`;
    
    // Helper function to handle rate limiting with Retry-After header
    const makeRequestWithRetry = async (url, config, maxRetries = 3) => {
        for (let attempt = 0; attempt < maxRetries; attempt++) {
            try {
                const response = await axios.get(url, config);
                return response;
            } catch (error) {
                // Check if it's a 429 rate limit error
                if (error.response?.status === 429) {
                    const retryAfter = error.response.headers['retry-after'] || error.response.headers['Retry-After'];
                    const waitSeconds = retryAfter ? parseInt(retryAfter, 10) : 60; // Default to 60 seconds if header missing
                    
                    console.log(`Rate limit hit (429). Waiting ${waitSeconds} seconds before retry ${attempt + 1}/${maxRetries}...`);
                    
                    // Wait for the specified time
                    await new Promise(resolve => setTimeout(resolve, waitSeconds * 1000));
                    
                    // Continue to next iteration (retry)
                    continue;
                }
                
                // For other errors, throw immediately
                throw error;
            }
        }
        
        // If we've exhausted all retries, throw the last error
        throw new Error(`Request failed after ${maxRetries} retries`);
    };
    
    try {
        // Fetch invoice by ID with rate limit handling
        const invoiceResponse = await makeRequestWithRetry(invoiceUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Xero-tenant-id': tenantId,
                Accept: 'application/json',
            },
        });

        // Extract invoice from response (could be in Invoices array or single Invoice object)
        const invoice = invoiceResponse.data.Invoices?.[0] || invoiceResponse.data.Invoice || invoiceResponse.data;
        console.log(`Fetched invoice ${invoiceId}`);

        // Fetch additional data for the invoice
        const additionalData = {};

        // Fetch payments for this invoice
        try {
            const paymentsUrl = `https://api.xero.com/api.xro/2.0/Invoices/${invoiceId}/Payments`;
            const paymentsResponse = await makeRequestWithRetry(paymentsUrl, {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    'Xero-tenant-id': tenantId,
                    Accept: 'application/json',
                },
            });
            additionalData.payments = paymentsResponse.data.Payments || [];
            console.log(`Found ${additionalData.payments.length} payment(s) for invoice ${invoiceId}`);
        } catch (paymentError) {
            console.error(`Error fetching payments for invoice ${invoiceId}:`, paymentError.message);
            additionalData.payments = [];
        }

        // Fetch linked transactions for this invoice
        try {
            const linkedTransactionsWhere = `SourceTransactionID == Guid("${invoiceId}") OR TargetTransactionID == Guid("${invoiceId}")`;
            const linkedTransactionsUrl = `https://api.xero.com/api.xro/2.0/LinkedTransactions?where=${encodeURIComponent(linkedTransactionsWhere)}`;
            const linkedTransactionsResponse = await makeRequestWithRetry(linkedTransactionsUrl, {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    'Xero-tenant-id': tenantId,
                    Accept: 'application/json',
                },
            });
            additionalData.linkedTransactions = linkedTransactionsResponse.data.LinkedTransactions || [];
            console.log(`Found ${additionalData.linkedTransactions.length} linked transaction(s) for invoice ${invoiceId}`);
        } catch (linkedError) {
            console.error(`Error fetching linked transactions for invoice ${invoiceId}:`, linkedError.message);
            additionalData.linkedTransactions = [];
        }

        // Fetch contact details if contact ID exists
        if (invoice.Contact && invoice.Contact.ContactID) {
            try {
                const contactUrl = `https://api.xero.com/api.xro/2.0/Contacts/${invoice.Contact.ContactID}`;
                const contactResponse = await makeRequestWithRetry(contactUrl, {
                    headers: {
                        Authorization: `Bearer ${accessToken}`,
                        'Xero-tenant-id': tenantId,
                        Accept: 'application/json',
                    },
                });
                additionalData.contactDetails = contactResponse.data.Contacts?.[0] || contactResponse.data.Contacts || contactResponse.data;
                console.log(`Fetched contact details for invoice ${invoiceId}`);
            } catch (contactError) {
                console.error(`Error fetching contact details for invoice ${invoiceId}:`, contactError.message);
                additionalData.contactDetails = null;
            }
        }

        res.status(200).json({
            success: true,
            message: 'Invoice fetched successfully with additional data',
            invoiceId: invoiceId,
            invoice: invoice,
            payments: additionalData.payments,
            linkedTransactions: additionalData.linkedTransactions,
            contactDetails: additionalData.contactDetails
        });
    } catch (error) {
        console.error('Failed to fetch invoice from Xero:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch invoice from Xero',
            error: error.message,
            invoiceId: invoiceId
        });
    }
});

exports.getInvoiceByReference = tryCatchAsync(async (req, res) => {
    const accessToken = req.xeroAccessToken;
    const tenantId = req.xeroTenantId;
    const referenceId = req.query.referenceId || req.params.referenceId;

    // Check if Xero credentials are available
    if (!accessToken || !tenantId) {
        return res.status(401).json({
            success: false,
            message: 'Xero authentication required. Missing access token or tenant ID.',
            hasAccessToken: !!accessToken,
            hasTenantId: !!tenantId
        });
    }

    // Check if reference ID is provided
    if (!referenceId) {
        return res.status(400).json({
            success: false,
            message: 'Reference ID is required. Provide it as query parameter: ?referenceId=YOUR_REFERENCE_ID'
        });
    }

    // Helper function to handle rate limiting with Retry-After header
    const makeRequestWithRetry = async (url, config, maxRetries = 3) => {
        for (let attempt = 0; attempt < maxRetries; attempt++) {
            try {
                const response = await axios.get(url, config);
                return response;
            } catch (error) {
                // Check if it's a 429 rate limit error
                if (error.response?.status === 429) {
                    const retryAfter = error.response.headers['retry-after'] || error.response.headers['Retry-After'];
                    const waitSeconds = retryAfter ? parseInt(retryAfter, 10) : 60;
                    
                    console.log(`Rate limit hit (429). Waiting ${waitSeconds} seconds before retry ${attempt + 1}/${maxRetries}...`);
                    await new Promise(resolve => setTimeout(resolve, waitSeconds * 1000));
                    continue;
                }
                throw error;
            }
        }
        throw new Error(`Request failed after ${maxRetries} retries`);
    };

    try {
        // Search for invoices by Reference or InvoiceNumber
        // Xero API allows filtering by Reference field
        const where = `Reference == "${referenceId}" OR InvoiceNumber == "${referenceId}"`;
        const invoiceUrl = `https://api.xero.com/api.xro/2.0/Invoices?where=${encodeURIComponent(where)}`;

        const invoiceResponse = await makeRequestWithRetry(invoiceUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Xero-tenant-id': tenantId,
                Accept: 'application/json',
            },
        });

        const invoices = invoiceResponse.data.Invoices || [];
        console.log(`Found ${invoices.length} invoice(s) with reference ID: ${referenceId}`);

        res.status(200).json({
            success: true,
            message: 'Invoices fetched successfully',
            referenceId: referenceId,
            invoiceCount: invoices.length,
            invoices: invoices
        });
    } catch (error) {
        console.error('Failed to fetch invoices by reference ID from Xero:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch invoices by reference ID from Xero',
            error: error.message,
            referenceId: referenceId
        });
    }
});
