const { AuthorizationCode } = require('simple-oauth2');
const { tryCatchAsync } = require('./ErrorController');
const axios = require("axios");
const User = require('../modals/userModal');
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
exports.protect = tryCatchAsync(async (req, res, next) => {
    const token = req.cookies.token || req.query.token;

    if (!token) {
        // Check if it's an API request
        if (req.originalUrl.startsWith('/api/')) {
            return res.status(401).json({ 
                status: 'error', 
                message: 'Not authenticated',
                authenticated: false 
            });
        }
        return res.redirect('/login')
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.userId)
        user.xero = null
        req.user = user
    } catch (err) {
        // Check if it's an API request
        if (req.originalUrl.startsWith('/api/')) {
            return res.status(401).json({ 
                status: 'error', 
                message: 'Invalid or expired token',
                authenticated: false 
            });
        }
        return res.redirect('/login')
    }
    next();
})


exports.xeroClient = tryCatchAsync(async (req, res, next) => {
    const client = new AuthorizationCode({
        client: {
            id: process.env.XERO_CLIENT_ID,
            secret: process.env.XERO_CLIENT_SECRET,
        },
        auth: {
            tokenHost: 'https://identity.xero.com/connect/token',
            authorizePath: 'https://login.xero.com/identity/connect/authorize',
            tokenPath: '/connect/token',
        },
    });

    req.xeroClient = client;
    req.xeroScopes = "openid profile email offline_access accounting.contacts accounting.transactions";
    req.xeroRedirectUri = `${process.env.XERO_REDIRECT_URI}`;
    next();
})

exports.registerXero = tryCatchAsync(async (req, res) => {
    const client = req.xeroClient;
    const authorizationUri = client.authorizeURL({
        redirect_uri: req.xeroRedirectUri,
        scope: req.xeroScopes,
        state: 'random-string-123',
    });

    res.redirect(authorizationUri);
})

exports.registerXeroCallback = tryCatchAsync(async (req, res) => {
    const code = req.query.code;
    const client = req.xeroClient;
    const tokenParams = {
        code,
        redirect_uri: req.xeroRedirectUri,
        scope: req.xeroScopes,
    };

    const accessToken = await client.getToken(tokenParams);

    const connections = await axios.get("https://api.xero.com/connections", {
        headers: { Authorization: `Bearer ${accessToken.token.access_token}` },
    });

    const tenantId = connections.data[0].tenantId

    await User.findByIdAndUpdate(req.user._id, {
        xero: {
            access_token: accessToken.token.access_token,
            refresh_token: accessToken.token.refresh_token,
            expires_at: accessToken.token.expires_at,
            tenantId: tenantId,
            id_token: accessToken.token.id_token,
            token_type: "Bearer",
            expires_in: accessToken.token.expires_in,
            scope: req.xeroScopes
        }
    });

    return res.status(200).json('success');
})

exports.xeroTokenInfo = tryCatchAsync(async (req, res, next) => {
   const client = req.xeroClient;

  const user = await User.findById(req.user._id).lean();
  if (!user?.xero?.refresh_token) {
    throw new Error("No Xero token found");
  }

  let tokenSet = client.createToken({
    access_token: user.xero.access_token,
    refresh_token: user.xero.refresh_token,
    expires_at: user.xero.expires_at,
    token_type: "Bearer",
    scope: user.xero.scope
  });

  if (tokenSet.expired()) {
    console.log("Xero token expired, refreshing...");

    tokenSet = await tokenSet.refresh();

    await User.findByIdAndUpdate(req.user._id, {
      xero: {
        ...user.xero,
        access_token: tokenSet.token.access_token,
        refresh_token: tokenSet.token.refresh_token,
        expires_at: tokenSet.token.expires_at,
        scope: tokenSet.token.scope
      }
    });
  }

  // ALWAYS use tokenSet
  req.xeroAccessToken = tokenSet.token.access_token;
  req.xeroTenantId = user.xero.tenantId;
next()
})

// exports.createUser = tryCatchAsync(async (req, res) => {

//     const hashedPassword = await bcrypt.hash('Shaul@0302', 10);

//     try {
//         // optionally get data from req.body
//         // const { name, email, password, xero } = req.body;

//         const newUser = await User.create({
//             name: "John Doe",
//             email: "shaul@upvlu.com",
//             password: hashedPassword,
//             xero: {
//                 id_token: "id_token_here",
//                 access_token: "access_token_here",
//                 refresh_token: "refresh_token_here",
//                 token_type: "Bearer",
//                 expires_in: 1800,
//                 expires_at: new Date("2025-12-22T15:28:59.820Z"),
//                 scope: "openid profile email accounting.contacts accounting.transactions offline_access accounting.settings",
//                 tenantId: "08d7b547-a1123046d1b8"
//             }
//         });


//         const token = jwt.sign(
//             { userId: newUser._id },
//             process.env.JWT_SECRET,
//             { expiresIn: "7d" }
//         );
//         res.status(201)
//             .cookie("token", token, {
//                 httpOnly: true,
//                 secure: true,
//                 sameSite: "strict",
//                 maxAge: 7 * 24 * 60 * 60 * 1000
//             })
//             .json({
//                 status: "success",
//                 user: newUser
//             });
//     } catch (err) {
//         console.error("Error creating user:", err);
//         res.status(500).json({ status: "error", message: err.message });
//     }
// })


exports.login = tryCatchAsync(async (req, res) => {
    const { password, email } = req.body
console.log('hi')

    const user = await User.findOne({ email })

    if (!user) return res.status(404).json({ status: "error", message: "User not found" })
    console.log(user)

    if(!await bcrypt.compare(password, user.password)) {
        return res.status(400).json({ status: "error", message: "Incorrect password" })
    }

    const token = jwt.sign(
        { userId: user._id },
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
    );

    res.status(201)
        .cookie("token", token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: "lax",
            maxAge: 7 * 24 * 60 * 60 * 1000
        })
        .json({
            status: "success",
        });
})


exports.logout = tryCatchAsync(async (req, res) => {
  res
    .clearCookie('token', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax'
    })
    .status(200)
    .json({
      status: 'success',
      message: 'Logged out successfully'
    });
});
