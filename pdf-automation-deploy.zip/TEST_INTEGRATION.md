# Backend-Frontend Integration Test Guide

## Setup Complete! ✅

The following changes have been made to connect your backend with the frontend:

### 1. Fixed Authentication Middleware
- **Updated `protect` middleware** to return JSON responses for API routes instead of redirecting
- Now properly handles `/api/*` routes with 401 JSON responses
- Non-API routes still redirect to `/login` as expected

### 2. Fixed Cookie Settings
- **Updated cookie configuration** for development environment
- Changed `secure` flag to only be `true` in production
- Cookies now work correctly in development (http://localhost)

### 3. Existing Configuration (Already Correct)
- ✅ Vite proxy already configured to forward `/api/v1` and `/file` to `http://localhost:3001`
- ✅ Frontend already using correct API endpoints
- ✅ Backend routes properly configured

## How to Test

### Step 1: Start the Backend Server
```bash
npm start
# or for development with auto-reload:
npm run dev
```

The backend should start on `http://localhost:3001`

### Step 2: Start the Frontend (in a new terminal)
```bash
cd client
npm run dev
```

The frontend should start on `http://localhost:5173` (or similar Vite dev server port)

### Step 3: Test the Application

1. **Login Page**
   - Navigate to `http://localhost:5173/login`
   - Enter your credentials
   - Should successfully login and redirect to home page

2. **Protected Routes**
   - After login, you should be able to access:
     - `/` - Suppliers list
     - `/statements` - All statements
     - `/activity` - Activity page

3. **API Endpoints**
   - The frontend will make requests to:
     - `GET /api/v1/auth/check` - Check authentication
     - `POST /api/v1/auth/login` - User login
     - `POST /api/v1/auth/logout` - User logout
     - `GET /api/v1/invoice/get-suppliers` - Get suppliers list
     - `POST /api/v1/invoice/new-file` - Upload PDF file
     - `GET /api/v1/invoice/get-invoices` - Get invoices
     - `GET /api/v1/invoice/get-logs` - Get logs
     - And more...

## What Was Fixed

### Issue 1: API Routes Redirecting Instead of Returning JSON
**Before:**
```javascript
if (!token) {
    return res.redirect('/login')
}
```

**After:**
```javascript
if (!token) {
    if (req.originalUrl.startsWith('/api/')) {
        return res.status(401).json({ 
            status: 'error', 
            message: 'Not authenticated',
            authenticated: false 
        });
    }
    return res.redirect('/login')
}
```

### Issue 2: Secure Cookies Not Working in Development
**Before:**
```javascript
.cookie("token", token, {
    httpOnly: true,
    secure: true,  // ❌ Always true, breaks in development
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000
})
```

**After:**
```javascript
.cookie("token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',  // ✅ Only secure in production
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000
})
```

## Architecture Overview

```
Frontend (React + Vite)          Backend (Express + MongoDB)
http://localhost:5173            http://localhost:3001
     |                                    |
     |  Vite Proxy                        |
     |  /api/v1/* → :3001/api/v1/*       |
     |  /file/* → :3001/file/*           |
     |                                    |
     +------------------------------------+
                    |
              Cookie-based Auth
              (JWT in httpOnly cookie)
```

## Troubleshooting

### If cookies aren't being set:
1. Make sure you're NOT using `https://` in development
2. Check browser console for any CORS errors
3. Verify both servers are running

### If API calls fail:
1. Check the browser Network tab to see the actual request/response
2. Verify the backend is running on port 3001
3. Check for any error messages in the backend console

### If redirects don't work:
1. The Vite dev server handles client-side routing
2. Backend redirects won't work for React routes
3. Use `window.location.href = '/path'` in frontend code

## Environment Variables Required

Make sure your `.env` file has:
```env
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret_key
PORT=3001
XERO_CLIENT_ID=your_xero_client_id
XERO_CLIENT_SECRET=your_xero_client_secret
XERO_REDIRECT_URI=your_xero_redirect_uri
```

## Success Indicators

✅ Backend starts without errors on port 3001
✅ Frontend starts without errors (usually port 5173)
✅ Can access login page
✅ Can successfully login with credentials
✅ After login, can see suppliers list
✅ Can upload PDF files
✅ Authentication persists on page refresh
✅ Can logout successfully

Your backend and frontend are now properly integrated! 🎉
