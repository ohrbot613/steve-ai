import { Link } from "react-router-dom"
import styles from "../scss/Top.module.scss"

export default function Top() {
    return (
        <div className={styles.top}>
            <div className={styles.topLeft}>
                <p>Supplier Reconciliation</p>
                <div className={styles.topLeftLinks}>
                    <Link className={`${styles.topLeftLink} ${styles.topLeftLinkActive}`} to="/suppliers">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-text w-4 h-4" data-filename="layout" data-linenumber="39" data-visual-selector-id="layout39" data-source-location="layout:39:22" data-dynamic-content="false"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>
                        <p>Suppliers</p>
                    </Link>
                    <Link className={styles.topLeftLink} to="/suppliers">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-list w-4 h-4" data-filename="layout" data-linenumber="39" data-visual-selector-id="layout39" data-source-location="layout:39:22" data-dynamic-content="false"><path d="M3 12h.01"></path><path d="M3 18h.01"></path><path d="M3 6h.01"></path><path d="M8 12h13"></path><path d="M8 18h13"></path><path d="M8 6h13"></path></svg>
                        <p>All Statements</p>
                    </Link>
                    <Link className={styles.topLeftLink} to="/suppliers">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-activity w-4 h-4" data-filename="layout" data-linenumber="39" data-visual-selector-id="layout39" data-source-location="layout:39:22" data-dynamic-content="false"><path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"></path></svg>
                        <p>Activity</p>
                    </Link>
                </div>
            </div>
            <div className={styles.topRight}>
                <button>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-log-out w-4 h-4" data-filename="layout" data-linenumber="50" data-visual-selector-id="layout50" data-source-location="layout:50:14" data-dynamic-content="false"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" x2="9" y1="12" y2="12"></line></svg>
                    <p>Logout</p>
                </button>
            </div>
        </div>
    )
}