import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import './scss/main.scss'
import Login from './pages/Login'
import Activity from './pages/Activity'
import SupplierStatement from './pages/SupplierStatement'
import SupplierLogs from './pages/SupplierLogs'
import AllStatements from './pages/AllStatements'
import SingleStatement from './pages/SingleStatement'
import ProtectedRoute from './componentes/ProtectedRoute'

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route 
        path="/" 
        element={
          <ProtectedRoute>
            <Home />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/statements" 
        element={
          <ProtectedRoute>
            <AllStatements />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/activity" 
        element={
          <ProtectedRoute>
            <Activity />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/suppliers-statements/:supplierId" 
        element={
          <ProtectedRoute>
            <SupplierStatement />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/suppliers-logs/:supplierId" 
        element={
          <ProtectedRoute>
            <SupplierLogs />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/single-statement/:logId" 
        element={
          <ProtectedRoute>
            <SingleStatement />
          </ProtectedRoute>
        } 
      />
    </Routes>
  )
}

export default App
