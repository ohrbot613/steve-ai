import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import Top from "../componentes/Top";
import pageStyle from "../scss/Pages.module.scss"
import styles from "../scss/AllStatements.module.scss"

export default function AllStatements() {
    const [statements, setStatements] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchParams, setSearchParams] = useSearchParams();
    const [pages, setPages] = useState(1);
    const navigate = useNavigate();

    const page = Number(searchParams.get('page')) || 1;
    const sortBy = searchParams.get('sortBy') || 'processDateTime';
    const sortOrder = searchParams.get('sortOrder') || 'desc';

    useEffect(() => {
        async function getData() {
            setLoading(true);
            setError('');

            try {
                const response = await fetch(`/api/v1/invoice/get-all-logs?page=${page}&sortBy=${sortBy}&sortOrder=${sortOrder}`);

                if (!response.ok) {
                    throw new Error('Failed to fetch logs');
                }

                const data = await response.json();
                
                if (data.success) {
                    // Transform logs to display format
                    const transformedData = data.logs.map((log) => {
                        const supplierName = log.supplier?.name || 'Unknown Supplier';
                        const statementDate = log.invoiceIssueDate 
                            ? new Date(log.invoiceIssueDate).toLocaleDateString('en-US', { 
                                year: 'numeric', 
                                month: 'short', 
                                day: '2-digit' 
                            })
                            : 'Unknown Date';
                        
                        const processDateTime = new Date(log.addedAt).toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'short', 
                            day: '2-digit' 
                        }) + '\n' + new Date(log.addedAt).toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit',
                            hour12: false 
                        });
                        
                        // Determine status based on log status and unmatched count
                        let status = 'pending';
                        if (log.status === 'completed') {
                            if (log.unmatched === 0) {
                                status = 'reconciled';
                            } else if (log.unmatched === log.total) {
                                status = 'unreconciled';
                            } else {
                                status = 'partial';
                            }
                        } else if (log.status === 'failed') {
                            status = 'unreconciled';
                        }
                        
                        const reconciled = log.total - log.unmatched;
                        
                        return {
                            id: log._id,
                            supplier: supplierName,
                            statementIssueDate: statementDate,
                            processDateTime,
                            reconciled: Math.max(0, reconciled || 0),
                            unreconciled: Math.max(0, log.unmatched || 0),
                            total: log.total || 0,
                            fileId: log._id,
                            file: log.file,
                            addedAt: log.addedAt,
                            status
                        };
                    });
                    
                    setStatements(transformedData);
                    setPages(data.pages || 1);
                } else {
                    setError('Failed to load logs');
                }
            } catch (err) {
                setError('An error occurred while loading logs');
                console.error(err);
            } finally {
                setLoading(false);
            }
        }

        getData();
    }, [page, sortBy, sortOrder]);

    function handleColumnClick(columnName) {
        // If clicking the same column, toggle the order
        if (sortBy === columnName) {
            const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
            setSearchParams({ page: '1', sortBy: columnName, sortOrder: newOrder });
        } else {
            // If clicking a new column, default to descending
            setSearchParams({ page: '1', sortBy: columnName, sortOrder: 'desc' });
        }
    }

    function handlePrevPage() {
        if (page > 1) {
            setSearchParams({ page: String(page - 1), sortBy, sortOrder });
        }
    }

    function handleNextPage() {
        if (page < pages) {
            setSearchParams({ page: String(page + 1), sortBy, sortOrder });
        }
    }

    function getStatusBadge(status) {
        const statusConfig = {
            pending: { label: 'Pending', className: styles.statusPending },
            unreconciled: { label: 'Unreconciled', className: styles.statusUnreconciled },
            reconciled: { label: 'Fully Reconciled', className: styles.statusReconciled },
            partial: { label: 'Partially Reconciled', className: styles.statusPartial }
        };

        const config = statusConfig[status] || statusConfig.pending;

        return (
            <div className={`${styles.statusBadge} ${config.className}`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                </svg>
                <span>{config.label}</span>
            </div>
        );
    }

    function handleRowClick(statement) {
        if (statement.fileId) {
            navigate(`/single-statement/${statement.fileId}`, {
                state: { from: 'all-statements' }
            });
        }
    }

    return (
        <>
            <Top />
            <main className={pageStyle.main}>
                <div className={pageStyle.top}>
                    <h1>All Statements</h1>
                    <p>Cross-supplier statement overview</p>
                </div>

                {error && (
                    <div className={pageStyle.errorMessage}>
                        {error}
                    </div>
                )}

                {loading ? (
                    <div className={pageStyle.loading}>
                        <p>Loading statements...</p>
                    </div>
                ) : (
                    <div className={pageStyle.tableContainer}>
                        <table className={styles.statementsTable}>
                            <thead>
                                <tr>
                                    <th onClick={() => handleColumnClick('supplier')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            SUPPLIER {sortBy === 'supplier' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('statementIssueDate')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            STATEMENT ISSUE DATE {sortBy === 'statementIssueDate' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('processDateTime')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            PROCESS DATE/TIME {sortBy === 'processDateTime' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('status')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            STATUS {sortBy === 'status' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('reconciled')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            RECONCILED INVOICES {sortBy === 'reconciled' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('unreconciled')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            UNRECONCILED INVOICES {sortBy === 'unreconciled' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('total')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            TOTAL INVOICES {sortBy === 'total' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th>FILE</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {statements.length === 0 ? (
                                    <tr>
                                        <td colSpan="8" className={pageStyle.noData}>
                                            No statements found
                                        </td>
                                    </tr>
                                ) : (
                                    statements.map((statement) => (
                                        <tr
                                            key={statement.id}
                                            className={styles.statementRow}
                                            onClick={() => handleRowClick(statement)}
                                        >
                                            <td>
                                                <div className={styles.supplierName}>
                                                    {statement.supplier}
                                                </div>
                                            </td>
                                            <td>
                                                <div className={styles.dateText}>
                                                    {statement.statementIssueDate}
                                                </div>
                                            </td>
                                            <td>
                                                <div className={styles.dateTimeText}>
                                                    {statement.processDateTime}
                                                </div>
                                            </td>
                                            <td>
                                                {getStatusBadge(statement.status)}
                                            </td>
                                            <td>
                                                <div className={styles.reconciledNumber}>
                                                    {statement.reconciled}
                                                </div>
                                            </td>
                                            <td>
                                                <div className={styles.unreconciledNumber}>
                                                    {statement.unreconciled}
                                                </div>
                                            </td>
                                            <td>
                                                <div className={styles.totalNumber}>
                                                    {statement.total}
                                                </div>
                                            </td>
                                            <td onClick={(e) => e.stopPropagation()}>
                                                {statement.fileId ? (
                                                    <a 
                                                        href={`/file/${statement.fileId}`} 
                                                        target="_blank" 
                                                        rel="noopener noreferrer" 
                                                        className={pageStyle.downloadLink}
                                                    >
                                                        Download
                                                    </a>
                                                ) : (
                                                    <span className={styles.noFile}>—</span>
                                                )}
                                            </td>
                                            <td>
                                                <svg className={pageStyle.arrowIcon} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                    <path d="m9 18 6-6-6-6"></path>
                                                </svg>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                )}

                {!loading && statements.length > 0 && (
                    <div className={pageStyle.pagination}>
                        <button
                            onClick={handlePrevPage}
                            disabled={page <= 1}
                            className={pageStyle.pageButton}
                        >
                            Previous
                        </button>
                        <span className={pageStyle.pageCount}>
                            {page} / {pages === 0 ? 1 : pages}
                        </span>
                        <button
                            onClick={handleNextPage}
                            disabled={page >= pages}
                            className={pageStyle.pageButton}
                        >
                            Next
                        </button>
                    </div>
                )}
            </main>
        </>
    )
}
