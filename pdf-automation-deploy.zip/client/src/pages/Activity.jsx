import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import Top from "../componentes/Top";
import pageStyle from "../scss/Pages.module.scss";
import activityStyle from "../scss/Activity.module.scss";

export default function Activity() {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchParams, setSearchParams] = useSearchParams();
    const [pages, setPages] = useState(1);
    const navigate = useNavigate();

    const page = Number(searchParams.get('page')) || 1;

    useEffect(() => {
        async function getData() {
            setLoading(true);
            setError('');

            try {
                const response = await fetch(
                    `/api/v1/invoice/get-all-logs?page=${page}&includeSuperseded=true`
                );

                if (!response.ok) {
                    throw new Error('Failed to fetch activity logs');
                }

                const data = await response.json();
                
                if (data.success) {
                    setLogs(data.logs || []);
                    setPages(data.pages || 1);
                } else {
                    setError('Failed to load activity logs');
                }
            } catch (err) {
                setError('An error occurred while loading activity logs');
                console.error(err);
            } finally {
                setLoading(false);
            }
        }

        getData();
    }, [page]);

    function formatDate(dateString) {
        if (!dateString) return 'Unknown';
        const date = new Date(dateString);
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const day = date.getDate();
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const seconds = date.getSeconds();
        return `${month} ${day}, ${year} • ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    function getActivityMessage(log) {
        const status = log.status || '';
        const errors = typeof log.errors === 'number' ? log.errors : 0;
        const found = log.found || 0;
        
        // Get month and year from invoiceIssueDate
        let monthYear = '';
        if (log.invoiceIssueDate) {
            const date = new Date(log.invoiceIssueDate);
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            monthYear = `${monthNames[date.getMonth()]} ${date.getFullYear()}`;
        }

        if (status === 'Completed' && errors === 0) {
            return monthYear ? `Full reconciliation completed - all invoices matched` : 'Full reconciliation completed - all invoices matched';
        } else if (status === 'Completed' && errors > 0) {
            return monthYear 
                ? `Statement for ${monthYear} processed with ${errors} ${errors === 1 ? 'discrepancy' : 'discrepancies'}`
                : `Statement processed with ${errors} ${errors === 1 ? 'discrepancy' : 'discrepancies'}`;
        } else if (status === 'Started') {
            return monthYear 
                ? `New statement uploaded for ${monthYear}`
                : 'New statement uploaded';
        } else if (status === 'Completed') {
            return monthYear 
                ? `Statement for ${monthYear} processed successfully`
                : 'Statement processed successfully';
        } else {
            return 'Statement processed';
        }
    }

    function getActivityIcon(log) {
        const status = log.status || '';
        const errors = typeof log.errors === 'number' ? log.errors : 0;

        if (status === 'Completed' && errors === 0) {
            return 'success';
        } else if (status === 'Started') {
            return 'upload';
        } else {
            return 'processed';
        }
    }

    function handlePrevPage() {
        if (page > 1) {
            setSearchParams({ page: String(page - 1) });
        }
    }

    function handleNextPage() {
        if (page < pages) {
            setSearchParams({ page: String(page + 1) });
        }
    }

    async function handleLogClick(log) {
        // If log is superseded, find the newer log that replaced it
        if (log.isSuperseded) {
            try {
                const response = await fetch(`/api/v1/invoice/get-newer-log?logId=${log._id}`);
                const data = await response.json();
                
                if (data.success && data.logId) {
                    navigate(`/single-statement/${data.logId}`, { 
                        state: { from: 'activity' } 
                    });
                } else {
                    // Fallback to original log if newer one not found
                    navigate(`/single-statement/${log._id}`, { 
                        state: { from: 'activity' } 
                    });
                }
            } catch (err) {
                console.error('Error fetching newer log:', err);
                // Fallback to original log on error
                navigate(`/single-statement/${log._id}`, { 
                    state: { from: 'activity' } 
                });
            }
        } else {
            navigate(`/single-statement/${log._id}`, { 
                state: { from: 'activity' } 
            });
        }
    }

    return (
        <>
            <Top />
            <main className={pageStyle.main}>
                <div className={pageStyle.top}>
                    <h1>Activity Log</h1>
                    <p>Processing history and system activity</p>
                </div>

                {error && (
                    <div className={pageStyle.errorMessage}>
                        {error}
                    </div>
                )}

                {loading ? (
                    <div className={pageStyle.loading}>
                        <p>Loading activity logs...</p>
                    </div>
                ) : (
                    <>
                        <div className={activityStyle.activityList}>
                            {logs.length === 0 ? (
                                <div className={activityStyle.noData}>
                                    No activity logs found
                                </div>
                            ) : (
                                logs.map((log) => {
                                    const iconType = getActivityIcon(log);
                                    const message = getActivityMessage(log);
                                    const supplierName = log.supplier?.name || 'Unknown Supplier';
                                    const dateStr = formatDate(log.addedAt);

                                    return (
                                        <div 
                                            key={log._id} 
                                            className={activityStyle.activityCard}
                                            onClick={() => handleLogClick(log)}
                                        >
                                            <div className={activityStyle.activityIconContainer}>
                                                <div className={`${activityStyle.activityIcon} ${activityStyle[iconType]}`}>
                                                    {iconType === 'success' ? (
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                            <path d="M20 6 9 17l-5-5"></path>
                                                        </svg>
                                                    ) : iconType === 'upload' ? (
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                                            <polyline points="17 8 12 3 7 8"></polyline>
                                                            <line x1="12" x2="12" y1="3" y2="15"></line>
                                                        </svg>
                                                    ) : (
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                            <path d="M20 6 9 17l-5-5"></path>
                                                        </svg>
                                                    )}
                                                </div>
                                            </div>
                                            <div className={activityStyle.activityContent}>
                                                <h3 className={activityStyle.activityTitle}>{message}</h3>
                                                <div className={activityStyle.activityDetails}>
                                                    <span className={activityStyle.supplierName}>Supplier: {supplierName}</span>
                                                    <span className={activityStyle.activityDate}>{dateStr}</span>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })
                            )}
                        </div>

                        <div className={pageStyle.pagination}>
                            <button
                                onClick={handlePrevPage}
                                disabled={page <= 1}
                                className={pageStyle.pageButton}
                            >
                                Previous
                            </button>
                            <span className={pageStyle.pageCount}>
                                {page} / {pages === 0 ? 1 : pages}
                            </span>
                            <button
                                onClick={handleNextPage}
                                disabled={page >= pages}
                                className={pageStyle.pageButton}
                            >
                                Next
                            </button>
                        </div>
                    </>
                )}
            </main>
        </>
    );
}

