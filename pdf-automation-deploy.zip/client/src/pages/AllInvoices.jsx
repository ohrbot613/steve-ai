import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import Top from "../componentes/Top";
import pageStyle from "../scss/Pages.module.scss";

export default function AllInvoices() {
    const [invoices, setInvoices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchParams, setSearchParams] = useSearchParams();
    const [pages, setPages] = useState(1);
    const navigate = useNavigate();

    const page = Number(searchParams.get('page')) || 1;

    useEffect(() => {
        async function getData() {
            setLoading(true);
            setError('');

            try {
                const response = await fetch(`/api/v1/invoice/get-all-invoices?page=${page}`);

                if (!response.ok) {
                    throw new Error('Failed to fetch invoices');
                }

                const data = await response.json();
                
                if (data.success) {
                    setInvoices(data.invoices || []);
                    setPages(data.pages || 1);
                } else {
                    setError('Failed to load invoices');
                }
            } catch (err) {
                setError('An error occurred while loading invoices');
                console.error(err);
            } finally {
                setLoading(false);
            }
        }

        getData();
    }, [page]);

    function formatDate(dateString) {
        if (!dateString) return '—';
        const date = new Date(dateString);
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const day = date.getDate();
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();
        return `${month} ${day}, ${year}`;
    }

    function formatCurrency(amount, currency = '$') {
        if (amount == null) return '—';
        return `${currency}${Number(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }

    function handlePrevPage() {
        if (page > 1) {
            setSearchParams({ page: String(page - 1) });
        }
    }

    function handleNextPage() {
        if (page < pages) {
            setSearchParams({ page: String(page + 1) });
        }
    }

    function handleRowClick(invoice) {
        if (invoice.log?._id) {
            navigate(`/single-statement/${invoice.log._id}`, {
                state: { from: 'all-invoices' }
            });
        }
    }

    return (
        <>
            <Top />
            <main className={pageStyle.main}>
                <div className={pageStyle.top}>
                    <h1>All Invoices</h1>
                    <p>Complete invoice listing across all suppliers</p>
                </div>

                {error && (
                    <div className={pageStyle.errorMessage}>
                        {error}
                    </div>
                )}

                {loading ? (
                    <div className={pageStyle.loading}>
                        <p>Loading invoices...</p>
                    </div>
                ) : (
                    <>
                        <div className={pageStyle.tableContainer}>
                            <table className={pageStyle.suppliersTable}>
                                <thead>
                                    <tr>
                                        <th>SUPPLIER</th>
                                        <th>INVOICE NUMBER</th>
                                        <th>SUPPLIER DATE</th>
                                        <th>SYSTEM DATE</th>
                                        <th>SUPPLIER AMOUNT</th>
                                        <th>SYSTEM AMOUNT</th>
                                        <th>DIFFERENCE</th>
                                        <th>FOUND IN SYSTEM</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {invoices.length === 0 ? (
                                        <tr>
                                            <td colSpan="8" className={pageStyle.noData}>
                                                No invoices found
                                            </td>
                                        </tr>
                                    ) : (
                                        invoices.map((invoice) => {
                                            const supplierAmount = invoice.amount?.amount || 0;
                                            const systemAmount = invoice.amountXero?.amount || 0;
                                            const difference = supplierAmount - systemAmount;
                                            const currency = invoice.currency || '$';
                                            const foundInSystem = invoice.invoiceXeroDate ? 'Yes' : 'No';

                                            return (
                                                <tr 
                                                    key={invoice._id} 
                                                    className={pageStyle.supplierRow}
                                                    onClick={() => handleRowClick(invoice)}
                                                    style={{ cursor: invoice.log?._id ? 'pointer' : 'default' }}
                                                >
                                                    <td>
                                                        <strong>{invoice.supplier?.name || 'Unknown'}</strong>
                                                    </td>
                                                    <td>{invoice.invoiceNumber || '—'}</td>
                                                    <td>{formatDate(invoice.invoiceDate)}</td>
                                                    <td>{formatDate(invoice.invoiceXeroDate)}</td>
                                                    <td>{formatCurrency(supplierAmount, currency)}</td>
                                                    <td>{formatCurrency(systemAmount, currency)}</td>
                                                    <td className={difference !== 0 ? pageStyle.unreconciled : pageStyle.reconciled}>
                                                        {formatCurrency(difference, currency)}
                                                    </td>
                                                    <td>{foundInSystem}</td>
                                                </tr>
                                            );
                                        })
                                    )}
                                </tbody>
                            </table>
                        </div>

                        <div className={pageStyle.pagination}>
                            <button
                                onClick={handlePrevPage}
                                disabled={page <= 1}
                                className={pageStyle.pageButton}
                            >
                                Previous
                            </button>
                            <span className={pageStyle.pageCount}>
                                {page} / {pages === 0 ? 1 : pages}
                            </span>
                            <button
                                onClick={handleNextPage}
                                disabled={page >= pages}
                                className={pageStyle.pageButton}
                            >
                                Next
                            </button>
                        </div>
                    </>
                )}
            </main>
        </>
    );
}



