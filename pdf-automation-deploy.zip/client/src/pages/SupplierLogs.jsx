import { useEffect, useState } from "react";
import { useSearchParams, useParams, Link, useNavigate } from "react-router-dom";
import Top from "../componentes/Top";
import pageStyle from "../scss/Pages.module.scss";

export default function SupplierLogs() {
    const [logs, setLogs] = useState([]);
    const [invoices, setInvoices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchParams, setSearchParams] = useSearchParams();
    const [pages, setPages] = useState(1);
    const [invoicePages, setInvoicePages] = useState(1);
    const [activeTab, setActiveTab] = useState('statements');
    const { supplierId } = useParams();
    const navigate = useNavigate();
    
    const supplierName = searchParams.get('name') || 'Supplier';
    const page = Number(searchParams.get('page')) || 1;
    const invoicePage = Number(searchParams.get('invoicePage')) || 1;
    const sortBy = searchParams.get('sortBy') || 'processDateTime';
    const sortOrder = searchParams.get('sortOrder') || 'desc';

    useEffect(() => {
        if (activeTab === 'statements') {
            async function getData() {
                setLoading(true);
                setError('');

                try {
                    const response = await fetch(
                        `/api/v1/invoice/get-logs?id=${supplierId}&page=${page}&sortBy=${sortBy}&sortOrder=${sortOrder}`
                    );

                    if (!response.ok) {
                        throw new Error('Failed to fetch logs');
                    }

                    const data = await response.json();
                    
                    if (data.success) {
                        setLogs(data.logs || []);
                        setPages(data.pages || 1);
                    } else {
                        setError('Failed to load logs');
                    }
                } catch (err) {
                    setError('An error occurred while loading logs');
                    console.error(err);
                } finally {
                    setLoading(false);
                }
            }

            getData();
        }
    }, [supplierId, page, sortBy, sortOrder, activeTab]);

    useEffect(() => {
        if (activeTab === 'invoices') {
            async function getInvoices() {
                setLoading(true);
                setError('');

                try {
                    const response = await fetch(
                        `/api/v1/invoice/get-invoices-by-supplier?supplierId=${supplierId}&page=${invoicePage}`
                    );

                    if (!response.ok) {
                        throw new Error('Failed to fetch invoices');
                    }

                    const data = await response.json();
                    
                    if (data.success) {
                        setInvoices(data.invoices || []);
                        setInvoicePages(data.pages || 1);
                    } else {
                        setError('Failed to load invoices');
                    }
                } catch (err) {
                    setError('An error occurred while loading invoices');
                    console.error(err);
                } finally {
                    setLoading(false);
                }
            }

            getInvoices();
        }
    }, [supplierId, invoicePage, activeTab]);

    function formatDate(dateString) {
        if (!dateString) return '—';
        const date = new Date(dateString);
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const day = date.getDate();
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();
        return `${month} ${day}, ${year}`;
    }

    function formatDateTime(dateString) {
        if (!dateString) return '—';
        const date = new Date(dateString);
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const day = date.getDate();
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();
        const hours = date.getHours();
        const minutes = date.getMinutes();
        return `${month} ${day}, ${year} ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    }

    function formatCurrency(amount, currency = '$') {
        if (amount == null) return '—';
        return `${currency}${Number(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }

    function getStatusBadge(log) {
        const status = log.status || '';
        const unmatched = typeof log.unmatched === 'number' ? log.unmatched : 0;

        if (status === 'completed' && unmatched === 0) {
            return <span className={pageStyle.statusSuccess}>Fully Reconciled</span>;
        } else if (status === 'completed' && unmatched > 0) {
            return <span className={pageStyle.statusWarning}>Partially Reconciled</span>;
        } else if (status === 'failed') {
            return <span className={pageStyle.statusError}>Unreconciled</span>;
        } else {
            return <span className={pageStyle.statusProcessing}>Processing</span>;
        }
    }

    function handleColumnClick(columnName) {
        // If clicking the same column, toggle the order
        if (sortBy === columnName) {
            const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
            setSearchParams({ page: '1', sortBy: columnName, sortOrder: newOrder, name: supplierName });
        } else {
            // If clicking a new column, default to descending
            setSearchParams({ page: '1', sortBy: columnName, sortOrder: 'desc', name: supplierName });
        }
    }

    function handlePrevPage() {
        if (activeTab === 'statements' && page > 1) {
            setSearchParams({ page: String(page - 1), sortBy, sortOrder, name: supplierName });
        } else if (activeTab === 'invoices' && invoicePage > 1) {
            setSearchParams({ invoicePage: String(invoicePage - 1), name: supplierName });
        }
    }

    function handleNextPage() {
        if (activeTab === 'statements' && page < pages) {
            setSearchParams({ page: String(page + 1), sortBy, sortOrder, name: supplierName });
        } else if (activeTab === 'invoices' && invoicePage < invoicePages) {
            setSearchParams({ invoicePage: String(invoicePage + 1), name: supplierName });
        }
    }

    function handleInvoiceRowClick(invoice) {
        if (invoice.log?._id) {
            navigate(`/single-statement/${invoice.log._id}`, {
                state: { from: 'supplier-logs' }
            });
        }
    }

    function handleRowClick(logId) {
        navigate(`/single-statement/${logId}`, { 
            state: { from: 'supplier-logs' } 
        });
    }

    return (
        <>
            <Top />
            <main className={pageStyle.main}>
                <Link to="/" className={pageStyle.back}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m15 18-6-6 6-6"></path>
                    </svg>
                    Back to Suppliers
                </Link>

                <div className={pageStyle.top}>
                    <h1>{supplierName}</h1>
                    <p>{activeTab === 'statements' ? 'Reconciliation statements' : 'All invoices'}</p>
                </div>

                <div className={pageStyle.tabContainer}>
                    <div className={pageStyle.sideTabs}>
                        <button
                            className={`${pageStyle.tabButton} ${activeTab === 'statements' ? pageStyle.tabActive : ''}`}
                            onClick={() => {
                                setActiveTab('statements');
                                setSearchParams({ page: '1', sortBy, sortOrder, name: supplierName });
                            }}
                        >
                            Statements
                        </button>
                        <button
                            className={`${pageStyle.tabButton} ${activeTab === 'invoices' ? pageStyle.tabActive : ''}`}
                            onClick={() => {
                                setActiveTab('invoices');
                                setSearchParams({ invoicePage: '1', name: supplierName });
                            }}
                        >
                            All Invoices
                        </button>
                    </div>
                    <div className={pageStyle.tabContent}>

                {error && (
                    <div className={pageStyle.errorMessage}>
                        {error}
                    </div>
                )}

                        {loading ? (
                            <div className={pageStyle.loading}>
                                <p>Loading {activeTab === 'statements' ? 'logs' : 'invoices'}...</p>
                            </div>
                        ) : (
                            <>
                                {activeTab === 'statements' ? (
                                    <>
                                        <div className={pageStyle.tableContainer}>
                                            <table className={pageStyle.suppliersTable}>
                                                <thead>
                                                    <tr>
                                                        <th onClick={() => handleColumnClick('statementIssueDate')} style={{ cursor: 'pointer' }}>
                                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                                                STATEMENT ISSUE DATE {sortBy === 'statementIssueDate' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                                            </span>
                                                        </th>
                                                        <th onClick={() => handleColumnClick('processDateTime')} style={{ cursor: 'pointer' }}>
                                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                                                PROCESS DATE/TIME {sortBy === 'processDateTime' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                                            </span>
                                                        </th>
                                                        <th onClick={() => handleColumnClick('status')} style={{ cursor: 'pointer' }}>
                                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                                                STATUS {sortBy === 'status' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                                            </span>
                                                        </th>
                                                        <th onClick={() => handleColumnClick('reconciled')} style={{ cursor: 'pointer' }}>
                                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                                                RECONCILED {sortBy === 'reconciled' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                                            </span>
                                                        </th>
                                                        <th onClick={() => handleColumnClick('unreconciled')} style={{ cursor: 'pointer' }}>
                                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                                                UNRECONCILED {sortBy === 'unreconciled' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                                            </span>
                                                        </th>
                                                        <th onClick={() => handleColumnClick('total')} style={{ cursor: 'pointer' }}>
                                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                                                TOTAL {sortBy === 'total' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                                            </span>
                                                        </th>
                                                        <th>FILE</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {logs.length === 0 ? (
                                                        <tr>
                                                            <td colSpan="8" className={pageStyle.noData}>
                                                                No logs found for this supplier
                                                            </td>
                                                        </tr>
                                                    ) : (
                                                        logs.map((log) => {
                                                            const reconciled = log.total - log.unmatched || 0;
                                                            const unreconciled = log.unmatched || 0;
                                                            const total = reconciled + unreconciled;
                                                         
                                                            return (
                                                                <tr 
                                                                    key={log._id} 
                                                                    className={pageStyle.supplierRow}
                                                                    onClick={() => handleRowClick(log._id)}
                                                                >
                                                                    <td>
                                                                        <strong>{formatDate(log.invoiceIssueDate)}</strong>
                                                                    </td>
                                                                    <td>{formatDateTime(log.addedAt)}</td>
                                                                    <td>{getStatusBadge(log)}</td>
                                                                    <td className={pageStyle.reconciled}>{reconciled}</td>
                                                                    <td className={pageStyle.unreconciled}>{unreconciled}</td>
                                                                    <td>{total}</td>
                                                                    <td onClick={(e) => e.stopPropagation()}>
                                                                        <a href={`/file/${log._id}`} target="_blank" rel="noopener noreferrer" className={pageStyle.downloadLink}>
                                                                            Download
                                                                        </a>
                                                                    </td>
                                                                    <td>
                                                                        <svg className={pageStyle.arrowIcon} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                                            <path d="m9 18 6-6-6-6"></path>
                                                                        </svg>
                                                                    </td>
                                                                </tr>
                                                            );
                                                        })
                                                    )}
                                                </tbody>
                                            </table>
                                        </div>

                                        <div className={pageStyle.pagination}>
                                            <button
                                                onClick={handlePrevPage}
                                                disabled={page <= 1}
                                                className={pageStyle.pageButton}
                                            >
                                                Previous
                                            </button>
                                            <span className={pageStyle.pageCount}>
                                                {page} / {pages === 0 ? 1 : pages}
                                            </span>
                                            <button
                                                onClick={handleNextPage}
                                                disabled={page >= pages}
                                                className={pageStyle.pageButton}
                                            >
                                                Next
                                            </button>
                                        </div>
                                    </>
                                ) : (
                                    <>
                                        <div className={pageStyle.tableContainer}>
                                            <table className={pageStyle.suppliersTable}>
                                                <thead>
                                                    <tr>
                                                        <th>INVOICE NUMBER</th>
                                                        <th>SUPPLIER DATE</th>
                                                        <th>SYSTEM DATE</th>
                                                        <th>SUPPLIER AMOUNT</th>
                                                        <th>SYSTEM AMOUNT</th>
                                                        <th>DIFFERENCE</th>
                                                        <th>FOUND IN SYSTEM</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {invoices.length === 0 ? (
                                                        <tr>
                                                            <td colSpan="7" className={pageStyle.noData}>
                                                                No invoices found for this supplier
                                                            </td>
                                                        </tr>
                                                    ) : (
                                                        invoices.map((invoice) => {
                                                            const supplierAmount = invoice.amount?.amount || 0;
                                                            const systemAmount = invoice.amountXero?.amount || 0;
                                                            const difference = supplierAmount - systemAmount;
                                                            const currency = invoice.currency || '$';
                                                            const foundInSystem = invoice.invoiceXeroDate ? 'Yes' : 'No';

                                                            return (
                                                                <tr 
                                                                    key={invoice._id} 
                                                                    className={pageStyle.supplierRow}
                                                                    onClick={() => handleInvoiceRowClick(invoice)}
                                                                    style={{ cursor: invoice.log?._id ? 'pointer' : 'default' }}
                                                                >
                                                                    <td>
                                                                        <strong>{invoice.invoiceNumber || '—'}</strong>
                                                                    </td>
                                                                    <td>{formatDate(invoice.invoiceDate)}</td>
                                                                    <td>{formatDate(invoice.invoiceXeroDate)}</td>
                                                                    <td>{formatCurrency(supplierAmount, currency)}</td>
                                                                    <td>{formatCurrency(systemAmount, currency)}</td>
                                                                    <td className={difference !== 0 ? pageStyle.unreconciled : pageStyle.reconciled}>
                                                                        {formatCurrency(difference, currency)}
                                                                    </td>
                                                                    <td>{foundInSystem}</td>
                                                                </tr>
                                                            );
                                                        })
                                                    )}
                                                </tbody>
                                            </table>
                                        </div>

                                        <div className={pageStyle.pagination}>
                                            <button
                                                onClick={handlePrevPage}
                                                disabled={invoicePage <= 1}
                                                className={pageStyle.pageButton}
                                            >
                                                Previous
                                            </button>
                                            <span className={pageStyle.pageCount}>
                                                {invoicePage} / {invoicePages === 0 ? 1 : invoicePages}
                                            </span>
                                            <button
                                                onClick={handleNextPage}
                                                disabled={invoicePage >= invoicePages}
                                                className={pageStyle.pageButton}
                                            >
                                                Next
                                            </button>
                                        </div>
                                    </>
                                )}
                            </>
                        )}
                    </div>
                </div>
            </main>
        </>
    );
}
