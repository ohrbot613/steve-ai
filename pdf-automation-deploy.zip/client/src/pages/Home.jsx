import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import Top from "../componentes/Top";
import pageStyle from "../scss/Pages.module.scss"

export default function Home() {
    const [suppliers, setSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchParams, setSearchParams] = useSearchParams();
    const [pages, setPages] = useState(1);
    const [uploadLoading, setUploadLoading] = useState(false);
    const [uploadSuccess, setUploadSuccess] = useState('');
    const [uploadError, setUploadError] = useState('');
    const [isDragging, setIsDragging] = useState(false);

    const page = Number(searchParams.get('page')) || 1;
    const search = searchParams.get('search') || '';

    useEffect(() => {
        async function getData() {
            setLoading(true);
            setError('');

            try {
                const response = await fetch(
                    `/api/v1/invoice/get-suppliers?page=${page}&search=${encodeURIComponent(search)}`
                );

                if (!response.ok) {
                    throw new Error('Failed to fetch suppliers');
                }

                const data = await response.json();
                
                if (data.success) {
                    setSuppliers(data.suppliers || []);
                    setPages(data.pages || 1);
                } else {
                    setError('Failed to load suppliers');
                }
            } catch (err) {
                setError('An error occurred while loading suppliers');
                console.error(err);
            } finally {
                setLoading(false);
            }
        }

        getData();
    }, [page, search]);

    function handleSearch(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const searchValue = formData.get('search') || '';
        setSearchParams({ page: '1', search: searchValue });
    }

    function handleSupplierClick(supplierId, supplierName) {
        window.location.href = `/suppliers-logs/${supplierId}?name=${encodeURIComponent(supplierName)}`;
    }

    function handlePrevPage() {
        if (page > 1) {
            setSearchParams({ page: String(page - 1), ...(search && { search }) });
        }
    }

    function handleNextPage() {
        if (page < pages) {
            setSearchParams({ page: String(page + 1), ...(search && { search }) });
        }
    }

    async function handleFileUpload(file) {
        if (!file) return;

        // Validate file type (PDF or Excel)
        const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
        const allowedExtensions = ['.pdf', '.xlsx', '.xls'];
        const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
        
        if (!allowedTypes.includes(file.type) && !allowedExtensions.includes(fileExtension)) {
            setUploadError('Please upload a PDF or Excel file (.pdf, .xlsx, .xls)');
            return;
        }

        setUploadLoading(true);
        setUploadError('');
        setUploadSuccess('');

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/api/v1/invoice/parse-invoices', {
                method: 'POST',
                body: formData,
            });

            const data = await response.json();

            if (!response.ok) {
                // Extract error message from response
                const errorMessage = data.message || data.error?.message || 'Failed to parse invoices';
                throw new Error(errorMessage);
            }

            if (data.success) {
                // Build success message with parsing details
                let successMessage = `File "${data.fileName}" processed successfully!`;
                
                if (data.invoiceCountCheck) {
                    const check = data.invoiceCountCheck;
                    if (check.hasMultipleInvoices) {
                        successMessage += ` Found ${check.invoiceCount || 'multiple'} invoices.`;
                    } else {
                        successMessage += ` Found 1 invoice.`;
                    }
                }
                
                if (data.invoiceCount) {
                    successMessage += ` Extracted ${data.invoiceCount} invoice(s).`;
                }
                
                if (data.matching?.stats) {
                    const stats = data.matching.stats;
                    successMessage += ` Matched: ${stats.totalMatched}, Unmatched: ${stats.unmatchedFileCount + stats.unmatchedXeroCount}`;
                }
                
                if (data.savedToDatabase) {
                    successMessage += ` Saved to database.`;
                } else {
                    successMessage += ` (Not saved - supplier not found)`;
                }
                
                setUploadSuccess(successMessage);
                
                // Reload page after a short delay to show success message
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } else {
                throw new Error(data.message || 'Failed to process file');
            }
        } catch (err) {
            // Try to get detailed error message from response if available
            let errorMessage = 'An error occurred while processing the file';
            
            if (err.message) {
                errorMessage = err.message;
            } else if (err.response) {
                // If using axios or similar, check response
                errorMessage = err.response.data?.message || errorMessage;
            }
            
            setUploadError(errorMessage);
            console.error('File upload error:', err);
            setUploadLoading(false);
        }
    }

    function handleDragOver(e) {
        e.preventDefault();
        setIsDragging(true);
    }

    function handleDragLeave(e) {
        e.preventDefault();
        setIsDragging(false);
    }

    function handleDrop(e) {
        e.preventDefault();
        setIsDragging(false);
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileUpload(files[0]);
        }
    }

    function handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            handleFileUpload(files[0]);
        }
    }

    return (
        <>
            <Top />
            <main className={pageStyle.main}>
                <div className={pageStyle.top}>
                    <h1>Suppliers</h1>
                    <p>Overview of all suppliers and their statements</p>
                </div>

                {/* File Upload Section */}
                <div className={pageStyle.uploadSection}>
                    <div 
                        className={`${pageStyle.dropZone} ${isDragging ? pageStyle.dragging : ''} ${uploadLoading ? pageStyle.uploading : ''}`}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                    >
                        {uploadLoading ? (
                            <div className={pageStyle.uploadLoader}>
                                <div className={pageStyle.spinner}></div>
                                <p>Uploading and processing file...</p>
                            </div>
                        ) : (
                            <>
                                <svg className={pageStyle.uploadIcon} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                    <polyline points="17 8 12 3 7 8"></polyline>
                                    <line x1="12" y1="3" x2="12" y2="15"></line>
                                </svg>
                                <p>Drag and drop PDF or Excel file or browse</p>
                                <input 
                                    type="file" 
                                    accept=".pdf,.xlsx,.xls,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
                                    onChange={handleFileSelect}
                                    className={pageStyle.fileInput}
                                />
                                <button 
                                    type="button" 
                                    className={pageStyle.browseButton}
                                    onClick={() => document.querySelector(`.${pageStyle.fileInput}`).click()}
                                >
                                    Browse
                                </button>
                            </>
                        )}
                    </div>

                    {uploadSuccess && (
                        <div className={pageStyle.successMessage}>
                            {uploadSuccess}
                        </div>
                    )}

                    {uploadError && (
                        <div className={pageStyle.errorMessage}>
                            {uploadError}
                        </div>
                    )}
                </div>

                <form onSubmit={handleSearch} className={pageStyle.searchForm}>
                    <div className={pageStyle.searchInput}>
                        <input
                            type="text"
                            name="search"
                            placeholder="Search suppliers..."
                            defaultValue={search}
                        />
                        <button type="submit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                            </svg>
                        </button>
                    </div>
                </form>

                {error && (
                    <div className={pageStyle.errorMessage}>
                        {error}
                    </div>
                )}

                {loading ? (
                    <div className={pageStyle.loading}>
                        <p>Loading suppliers...</p>
                    </div>
                ) : (
                    <>
                        <div className={pageStyle.tableContainer}>
                            <table className={pageStyle.suppliersTable}>
                                <thead>
                                    <tr>
                                        <th>SUPPLIER NAME</th>
                                        <th>NUMBER OF STATEMENTS</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {suppliers.length === 0 ? (
                                        <tr>
                                            <td colSpan="2" className={pageStyle.noData}>
                                                No suppliers found
                                            </td>
                                        </tr>
                                    ) : (
                                        suppliers.map((supplier) => (
                                            <tr
                                                key={supplier._id}
                                                className={pageStyle.supplierRow}
                                                onClick={() => handleSupplierClick(supplier._id, supplier.name)}
                                            >
                                                <td>
                                                    <div className={pageStyle.supplierName}>
                                                        <svg className={pageStyle.documentIcon} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                            <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"></path>
                                                            <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"></path>
                                                            <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"></path>
                                                            <path d="M10 6h4"></path>
                                                            <path d="M10 10h4"></path>
                                                            <path d="M10 14h4"></path>
                                                            <path d="M10 18h4"></path>
                                                        </svg>
                                                        <span>{supplier.name}</span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className={pageStyle.statementCount}>
                                                        <span>{supplier.invoiceCount || 0} statements</span>
                                                        <svg className={pageStyle.arrowIcon} xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                            <path d="m9 18 6-6-6-6"></path>
                                                        </svg>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>

                        <div className={pageStyle.pagination}>
                            <button
                                onClick={handlePrevPage}
                                disabled={page <= 1}
                                className={pageStyle.pageButton}
                            >
                                Previous
                            </button>
                            <span className={pageStyle.pageCount}>
                                {page} / {pages === 0 ? 1 : pages}
                            </span>
                            <button
                                onClick={handleNextPage}
                                disabled={page >= pages}
                                className={pageStyle.pageButton}
                            >
                                Next
                            </button>
                        </div>
                    </>
                )}
            </main>
        </>
    )
}
