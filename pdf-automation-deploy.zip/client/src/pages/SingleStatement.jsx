import { useEffect, useState } from "react";
import { useParams, useNavigate, useLocation, useSearchParams } from "react-router-dom";
import Top from "../componentes/Top";
import pageStyle from "../scss/Pages.module.scss";

export default function SingleStatement() {
    const { logId } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams, setSearchParams] = useSearchParams();
    const [invoices, setInvoices] = useState([]);
    const [logInfo, setLogInfo] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [pages, setPages] = useState(1);
    
    const page = Number(searchParams.get('page')) || 1;
    const sortBy = searchParams.get('sortBy') || 'systemDate';
    const sortOrder = searchParams.get('sortOrder') || 'asc';

    useEffect(() => {
        async function getData() {
            setLoading(true);
            setError('');

            try {
                const response = await fetch(`/api/v1/invoice/get-invoices?id=${logId}&page=${page}&sortBy=${sortBy}&sortOrder=${sortOrder}`);

                if (!response.ok) {
                    throw new Error('Failed to fetch statement details');
                }

                const data = await response.json();
                
                if (data.success) {
                    setInvoices(data.invoices || []);
                    setPages(data.pages || 1);
                    // Extract log info from first invoice (all invoices share same log)
                    if (data.invoices && data.invoices.length > 0) {
                        const firstInvoice = data.invoices[0];
                        setLogInfo({
                            ...firstInvoice.log,
                            supplier: firstInvoice.supplier || firstInvoice.log?.supplier
                        });
                    }
                } else {
                    setError('Failed to load statement details');
                }
            } catch (err) {
                setError('An error occurred while loading statement details');
                console.error(err);
            } finally {
                setLoading(false);
            }
        }

        getData();
    }, [logId, page, sortBy, sortOrder]);

    function handleColumnClick(columnName) {
        // If clicking the same column, toggle the order
        if (sortBy === columnName) {
            const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
            setSearchParams({ page: '1', sortBy: columnName, sortOrder: newOrder });
        } else {
            // If clicking a new column, default to ascending and reset to page 1
            setSearchParams({ page: '1', sortBy: columnName, sortOrder: 'asc' });
        }
    }

    function formatDate(dateString) {
        if (!dateString) return '—';
        const date = new Date(dateString);
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                           'July', 'August', 'September', 'October', 'November', 'December'];
        const day = date.getDate();
        const month = monthNames[date.getMonth()];
        const year = date.getFullYear();
        return `${month} ${day}, ${year}`;
    }

    function formatShortDate(dateString) {
        if (!dateString) return '—';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-GB');
    }

    function formatCurrency(amount, currency = 'USD') {
        if (amount === null || amount === undefined) return '—';
        return `${currency} ${Number(amount).toFixed(2)}`;
    }

    const supplierName = logInfo?.supplier?.name || 'Supplier';
    const statementDate = logInfo?.invoiceIssueDate ? formatDate(logInfo.invoiceIssueDate) : '—';

    // Determine back navigation based on location state or previous page
    const fromSupplierLogs = location.state?.from === 'supplier-logs';
    const supplierId = logInfo?.supplier?._id;

    function handleBackClick() {
        if (location.state?.from) {
            // Navigate back using browser history if we have state
            navigate(-1);
        } else if (fromSupplierLogs && supplierId) {
            // Go back to supplier logs
            navigate(`/suppliers-logs/${supplierId}?name=${encodeURIComponent(supplierName)}`);
        } else {
            // Default: go back to all statements
            navigate('/all-statements');
        }
    }

    const backButtonText = fromSupplierLogs 
        ? `Back to ${supplierName}` 
        : 'Back to All Statements';

    function handlePrevPage() {
        if (page > 1) {
            setSearchParams({ page: String(page - 1), sortBy, sortOrder });
        }
    }

    function handleNextPage() {
        if (page < pages) {
            setSearchParams({ page: String(page + 1), sortBy, sortOrder });
        }
    }

    return (
        <>
            <Top />
            <main className={pageStyle.main}>
                <button onClick={handleBackClick} className={pageStyle.back}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m15 18-6-6 6-6"></path>
                    </svg>
                    {backButtonText}
                </button>

                <div className={pageStyle.top}>
                    <h1>Supplier {supplierName}</h1>
                    <p>Statement issued on {statementDate}</p>
                </div>

                {error && (
                    <div className={pageStyle.errorMessage}>
                        {error}
                    </div>
                )}

                {loading ? (
                    <div className={pageStyle.loading}>
                        <p>Loading statement...</p>
                    </div>
                ) : (
                    <div className={pageStyle.tableContainer}>
                        <table className={pageStyle.suppliersTable}>
                            <thead>
                                <tr>
                                    <th onClick={() => handleColumnClick('referenceId')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            REFERENCE ID {sortBy === 'referenceId' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('foundInSystem')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            FOUND IN SYSTEM {sortBy === 'foundInSystem' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('supplierDate')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            SUPPLIER DATE {sortBy === 'supplierDate' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('systemDate')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            SYSTEM DATE {sortBy === 'systemDate' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('supplierAmount')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            SUPPLIER AMOUNT {sortBy === 'supplierAmount' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th onClick={() => handleColumnClick('systemAmount')} style={{ cursor: 'pointer' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                            SYSTEM AMOUNT {sortBy === 'systemAmount' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                                        </span>
                                    </th>
                                    <th>DIFFERENCE</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                {invoices.length === 0 ? (
                                    <tr>
                                        <td colSpan="8" className={pageStyle.noData}>
                                            No invoices found for this statement
                                        </td>
                                    </tr>
                                ) : (
                                    invoices.map((invoice) => {
                                        const supplierAmount = invoice.amount?.amount || 0;
                                        const systemAmount = invoice.amountXero?.amount || 0;
                                        const difference = supplierAmount - systemAmount;
                                        const currency = invoice.currency || 'USD';
                                        const foundInSystem = invoice.invoiceXeroDate ? 'Yes' : 'No';

                                        return (
                                            <tr key={invoice._id} className={pageStyle.supplierRow}>
                                                <td>{invoice.invoiceNumber || '—'}</td>
                                                <td>
                                                    {foundInSystem === 'Yes' ? (
                                                        <span style={{ color: '#059669', fontWeight: '600' }}>Yes</span>
                                                    ) : (
                                                        <span style={{ color: '#dc2626', fontWeight: '600' }}>No</span>
                                                    )}
                                                </td>
                                                <td>{formatShortDate(invoice.invoiceDate)}</td>
                                                <td>{formatShortDate(invoice.invoiceXeroDate)}</td>
                                                <td>{formatCurrency(supplierAmount, currency)}</td>
                                                <td>{formatCurrency(systemAmount, currency)}</td>
                                                <td>
                                                    <span style={{ 
                                                        color: difference !== 0 ? '#dc2626' : '#059669',
                                                        fontWeight: '600'
                                                    }}>
                                                        {formatCurrency(Math.abs(difference), currency)}
                                                    </span>
                                                </td>
                                                <td>—</td>
                                            </tr>
                                        );
                                    })
                                )}
                            </tbody>
                        </table>
                    </div>
                )}

                {!loading && invoices.length > 0 && pages > 1 && (
                    <div className={pageStyle.pagination}>
                        <button
                            onClick={handlePrevPage}
                            disabled={page <= 1}
                            className={pageStyle.pageButton}
                        >
                            Previous
                        </button>
                        <span className={pageStyle.pageCount}>
                            {page} / {pages === 0 ? 1 : pages}
                        </span>
                        <button
                            onClick={handleNextPage}
                            disabled={page >= pages}
                            className={pageStyle.pageButton}
                        >
                            Next
                        </button>
                    </div>
                )}
            </main>
        </>
    );
}
