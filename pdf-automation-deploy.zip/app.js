const express = require("express");
const router = express.Router();
const authRoutes = require('./routes/authRoutes');// middleware (optional but common)
const invoiceRoutes = require('./routes/invoiceRoutes');// middleware (optional but common)
const viewRoutes = require('./routes/viewRoutes');// middleware (optional but common)
const path = require("path");
router.use(express.json());

router.use(express.static("public"));
router.use(express.static(path.join(__dirname, "views/index.html")));



router.use("/api/v1/auth", authRoutes);
router.use("/api/v1/invoice", invoiceRoutes);
router.use("/api/file", invoiceRoutes);
router.use("/", viewRoutes); // Add view routes (includes /file/:file) before catch-all

router.use((req, res) => {
  res.sendFile(path.join(__dirname, "views/index.html"));
});
module.exports = router;
