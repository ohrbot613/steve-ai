# Steve AI - User Guide

Welcome to Steve AI! This guide will help you understand how to use the application to process and reconcile supplier statements and invoices.

---

## 📋 Table of Contents

1. [Getting Started](#getting-started)
2. [Navigation Overview](#navigation-overview)
3. [Page-by-Page Guide](#page-by-page-guide)
4. [Common Tasks](#common-tasks)
5. [Understanding Status Indicators](#understanding-status-indicators)
6. [Tips & Best Practices](#tips--best-practices)

---

## 🚀 Getting Started

### Logging In

1. Navigate to the login page
2. Enter your **email** and **password**
3. Click **Sign in**

> **Note:** Google and Microsoft login options are currently not available. Please use your email and password.

---

## 🧭 Navigation Overview

The main navigation menu is located at the top of every page and includes:

- **Suppliers** - View all suppliers and upload files
- **All Statements** - View all statements across all suppliers
- **All Invoices** - View all invoices across all suppliers
- **Activity** - View processing history and system activity
- **Logout** - Sign out of your account

---

## 📄 Page-by-Page Guide

### 1. Suppliers Page (Home)

**What it does:** This is your main dashboard where you can view all suppliers and upload new statement files.

**Key Features:**
- **File Upload Area** - Drag and drop PDF or Excel files, or click "Browse" to select files
- **Search Bar** - Search for specific suppliers by name
- **Supplier List** - View all suppliers with the number of statements for each

**How to Use:**
1. **Upload a File:**
   - Drag and drop a PDF or Excel file into the upload area, OR
   - Click "Browse" and select a file from your computer
   - The system will automatically process the file and extract invoice information
   - You'll see a success message when processing is complete

2. **Find a Supplier:**
   - Use the search bar to filter suppliers by name
   - Click on any supplier row to view their statements and invoices

3. **Navigate:**
   - Use the Previous/Next buttons at the bottom to browse through multiple pages of suppliers

**Supported File Types:**
- PDF files (.pdf)
- Excel files (.xlsx, .xls)

---

### 2. All Statements Page

**What it does:** Provides a comprehensive view of all statements from all suppliers in one place.

**Key Features:**
- **Sortable Columns** - Click any column header to sort (click again to reverse order)
- **Status Indicators** - See at a glance which statements are fully reconciled, partially reconciled, or unreconciled
- **Download Files** - Download the original statement PDF
- **Detailed Information** - View supplier name, statement date, processing date, and reconciliation counts

**How to Use:**
1. **Sort Data:**
   - Click any column header (Supplier, Statement Issue Date, Process Date/Time, Status, etc.)
   - Click again to reverse the sort order
   - Look for the ↑ or ↓ arrow to see the current sort direction

2. **View Statement Details:**
   - Click on any row to view the detailed invoice breakdown for that statement

3. **Download Original File:**
   - Click the "Download" link in the FILE column to get the original PDF

4. **Navigate:**
   - Use Previous/Next buttons to browse through pages

**Status Meanings:**
- **Fully Reconciled** (green) - All invoices matched successfully
- **Partially Reconciled** (yellow) - Some invoices matched, some didn't
- **Unreconciled** (red) - No invoices matched
- **Pending** (gray) - Still processing

---

### 3. All Invoices Page

**What it does:** Shows every individual invoice across all suppliers, allowing you to see invoice-level details.

**Key Features:**
- **Invoice Comparison** - Compare supplier amounts vs. system (Xero) amounts
- **Difference Calculation** - Automatically calculates differences between supplier and system amounts
- **Found in System** - Shows whether each invoice was found in your accounting system
- **Supplier Information** - See which supplier each invoice belongs to

**How to Use:**
1. **Review Invoices:**
   - Browse through all invoices to identify discrepancies
   - Look at the "Difference" column - red indicates a mismatch, green indicates a match

2. **Investigate Discrepancies:**
   - Click on any invoice row to view the full statement it belongs to
   - Review the supplier date vs. system date to identify timing differences

3. **Navigate:**
   - Use Previous/Next buttons to browse through pages

**Column Explanations:**
- **Supplier** - The supplier name
- **Invoice Number** - The invoice reference number
- **Supplier Date** - Date from the supplier's statement
- **System Date** - Date from your accounting system (Xero)
- **Supplier Amount** - Amount from the supplier's statement
- **System Amount** - Amount from your accounting system
- **Difference** - The variance between supplier and system amounts
- **Found in System** - Yes/No indicating if the invoice exists in your system

---

### 4. Activity Page

**What it does:** Provides a chronological log of all file processing activities and system events.

**Key Features:**
- **Activity Timeline** - See all processing events in chronological order
- **Status Icons** - Visual indicators for different activity types
- **Processing Details** - View which statements were processed and their outcomes
- **Supplier Context** - See which supplier each activity relates to

**How to Use:**
1. **Review Recent Activity:**
   - Scroll through the activity list to see recent file uploads and processing results
   - Each card shows the activity type, supplier, and timestamp

2. **View Statement Details:**
   - Click on any activity card to view the detailed statement it relates to

3. **Navigate:**
   - Use Previous/Next buttons to browse through older activities

**Activity Types:**
- **Upload** (blue icon) - New file uploaded
- **Processed** (gray icon) - Statement processed with some discrepancies
- **Success** (green icon) - Full reconciliation completed - all invoices matched

---

### 5. Supplier Logs Page

**What it does:** Shows all statements and invoices for a specific supplier.

**Key Features:**
- **Two Tabs:**
  - **Statements Tab** - View all statements for this supplier
  - **All Invoices Tab** - View all invoices for this supplier
- **Sortable Data** - Sort statements by date, status, or reconciliation counts
- **Status Overview** - Quick view of reconciliation status for each statement

**How to Use:**
1. **Switch Between Views:**
   - Click the "Statements" tab to see all statements
   - Click the "All Invoices" tab to see all invoices for this supplier

2. **View Statement Details:**
   - Click on any statement row to see the detailed invoice breakdown
   - Click on any invoice row to view its parent statement

3. **Sort and Filter:**
   - Click column headers to sort (click again to reverse)
   - Use Previous/Next buttons to navigate through pages

4. **Download Files:**
   - Click "Download" in the FILE column to get the original statement PDF

5. **Go Back:**
   - Click "Back to Suppliers" at the top to return to the main suppliers list

---

### 6. Single Statement Page

**What it does:** Provides a detailed, line-by-line view of all invoices within a specific statement.

**Key Features:**
- **Invoice-by-Invoice Breakdown** - See every invoice in the statement
- **Detailed Comparison** - Compare supplier data vs. system data for each invoice
- **Sortable Columns** - Sort invoices by any column
- **Reconciliation Status** - See which invoices matched and which didn't

**How to Use:**
1. **Review Invoices:**
   - Scroll through the table to see all invoices in this statement
   - Look for invoices marked "No" in the "Found in System" column - these need attention

2. **Sort Data:**
   - Click column headers to sort invoices
   - Useful for grouping matched vs. unmatched invoices

3. **Identify Discrepancies:**
   - Check the "Difference" column - any non-zero amount indicates a mismatch
   - Review dates to identify timing differences

4. **Navigate:**
   - Use Previous/Next buttons if the statement has many invoices across multiple pages

5. **Go Back:**
   - Click the back button at the top to return to the previous page

**Column Explanations:**
- **Reference ID** - Invoice number or reference
- **Found in System** - Yes/No indicating if invoice exists in your accounting system
- **Supplier Date** - Date from the supplier's statement
- **System Date** - Date from your accounting system
- **Supplier Amount** - Amount from supplier's statement
- **System Amount** - Amount from your accounting system
- **Difference** - Variance between amounts (red = mismatch, green = match)

---

## ✅ Common Tasks

### Uploading a New Statement

1. Go to the **Suppliers** page
2. Drag and drop your PDF or Excel file into the upload area, OR click "Browse"
3. Wait for the processing to complete (you'll see a success message)
4. The page will automatically refresh to show the updated data

### Finding a Specific Supplier

1. Go to the **Suppliers** page
2. Type the supplier name in the search bar
3. Press Enter or click the search icon
4. Click on the supplier to view their statements

### Checking Reconciliation Status

1. Go to **All Statements** to see an overview
2. Look at the **Status** column for quick status indicators
3. Click on any statement to see detailed invoice-level reconciliation
4. Review the **Difference** column to identify discrepancies

### Reviewing Unmatched Invoices

1. Go to **All Invoices**
2. Look for invoices with "No" in the "Found in System" column
3. Click on the invoice to view its full statement context
4. Check the **Difference** column for amount mismatches

### Tracking Recent Activity

1. Go to the **Activity** page
2. Review the most recent activities at the top
3. Click on any activity card to view the related statement details

---

## 🎨 Understanding Status Indicators

### Statement Statuses

- **Fully Reconciled** (green badge)
  - All invoices in the statement were successfully matched
  - No action needed

- **Partially Reconciled** (yellow badge)
  - Some invoices matched, some didn't
  - Review the statement to identify unmatched invoices

- **Unreconciled** (red badge)
  - No invoices were matched
  - May indicate a supplier name mismatch or missing data

- **Pending** (gray badge)
  - Statement is still being processed
  - Wait a few moments and refresh

### Invoice Statuses

- **Found in System: Yes** (green text)
  - Invoice exists in your accounting system
  - Check the difference amount to verify it matches

- **Found in System: No** (red text)
  - Invoice not found in your accounting system
  - May need to be added manually or investigated

- **Difference: $0.00** (green text)
  - Amounts match perfectly between supplier and system

- **Difference: Non-zero** (red text)
  - Amount mismatch detected
  - Review both amounts to identify the discrepancy

---

## 💡 Tips & Best Practices

### File Upload Tips

- **File Format:** Ensure your files are PDF or Excel format
- **File Size:** Large files may take longer to process
- **File Quality:** Clear, readable PDFs work best for accurate extraction
- **Wait for Processing:** Don't navigate away immediately after uploading - wait for the success message

### Navigation Tips

- **Use Search:** The search function works on the Suppliers page to quickly find suppliers
- **Click to Drill Down:** Most tables allow you to click rows to see more details
- **Use Back Buttons:** Use the back buttons to navigate through the hierarchy
- **Sort Columns:** Click column headers to sort data - very useful for finding specific items

### Reconciliation Tips

- **Start with Status:** Check the status column first to identify problematic statements
- **Review Differences:** Focus on statements with non-zero differences
- **Check Dates:** Date mismatches are common - verify the supplier date vs. system date
- **Unmatched Invoices:** Invoices marked "No" in "Found in System" may need manual entry

### General Tips

- **Refresh After Upload:** The page auto-refreshes after successful uploads, but you can manually refresh if needed
- **Multiple Pages:** Use pagination controls to browse through large datasets
- **Download Originals:** Use the Download link to access original statement PDFs when needed
- **Activity Log:** Check the Activity page regularly to monitor system processing

---

## ❓ Need Help?

If you encounter any issues or have questions:

1. Check the **Activity** page to see if there were any processing errors
2. Verify your file format is supported (PDF or Excel)
3. Ensure the supplier name in your file matches an existing supplier in the system
4. Contact your system administrator for technical support

---

## 🔒 Security Notes

- Always log out when finished using the system
- Never share your login credentials
- Keep your files secure and only upload authorized documents

---

**Last Updated:** 2025

**Version:** 1.0

