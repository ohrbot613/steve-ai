const express = require("express");
const router = express.Router();
const path = require("path");
const viewController = require("../controllers/ViewController");

// File download route - must be before catch-all routes
router.get("/file/:file", viewController.file);

// Note: During development, Vite dev server serves the React app
// This route is only used in production after building the client
// For now, keeping it minimal to avoid Express 5.x path-to-regexp issues

// Uncomment and configure for production deployment when ready:
// router.use((req, res) => {
//     res.render('index');
// });


module.exports = router;
