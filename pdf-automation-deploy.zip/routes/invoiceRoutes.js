const express = require("express");
const router = express.Router();
const authController = require("../controllers/AuthController");
const invoiceController = require("../controllers/InvoiceController");

// router.post("/new-file", authController.protect,invoiceController.upload.single("file"), authController.xeroClient, authController.xeroTokenInfo, invoiceController.parseFiles );
router.post("/parse-invoices", authController.protect, invoiceController.upload.single("file"), authController.xeroClient, authController.xeroTokenInfo, invoiceController.parseInvoices);
router.get("/get-invoices", authController.protect, invoiceController.getInvoices);
router.get("/get-suppliers", authController.protect, invoiceController.getSuppliers);
router.get("/get-logs", authController.protect, invoiceController.getLogs);
router.get("/get-all-invoices", authController.protect, invoiceController.getAllInvoices);
router.get("/get-invoices-by-supplier", authController.protect, invoiceController.getInvoicesBySupplier);
router.get("/get-all-logs", authController.protect, invoiceController.getAllLogs);
router.get("/get-newer-log", authController.protect, invoiceController.getNewerLog);
// router.get("/test", authController.protect, authController.xeroClient, authController.xeroTokenInfo, invoiceController.test);
// router.get("/get-invoice-by-reference", authController.protect, authController.xeroClient, authController.xeroTokenInfo, invoiceController.getInvoiceByReference);
// router.get("/signup", authController.createUser);

module.exports = router;

