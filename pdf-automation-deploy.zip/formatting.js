const { geminiCall } = require("./gemini");

async function formatWithAIToStandardJSON(text, fileName = '', previousError = null, invoiceCountInfo = null) {
  let errorContext = '';
  if (previousError) {
    errorContext = `

PREVIOUS ATTEMPT FAILED:
${previousError}

IMPORTANT: The previous extraction had errors. Please fix the following issues:
- Review the error message above carefully
- Ensure each invoice has a UNIQUE invoice number
- If the file contains only ONE invoice, return an array with ONE invoice object
- If the file contains multiple invoices (like a statement), each must have a different invoice number
- Do NOT create multiple invoice objects with the same invoice number

`;
  }

  let invoiceCountContext = '';
  if (invoiceCountInfo) {
    if (invoiceCountInfo.hasMultipleInvoices === true) {
      invoiceCountContext = `

INVOICE COUNT ANALYSIS:
⚠️ CRITICAL: This document has been analyzed and contains MULTIPLE invoices/transactions.
- Expected invoice count: ${invoiceCountInfo.invoiceCount || 'multiple (exact count unknown)'}
- Reason: ${invoiceCountInfo.reason || 'Statement or table with multiple rows detected'}

EXTRACTION REQUIREMENTS FOR MULTIPLE INVOICES:
- You MUST extract EACH row/entry from the statement table as a SEPARATE invoice
- Each row MUST have its OWN unique invoice number
- Look for invoice numbers in columns like "Invoice No.", "Reference", "Our Reference", "Transaction ID", "Doc Number"
- If a row doesn't have an invoice number visible, look for it in adjacent columns or the row context
- DO NOT reuse the same invoice number for multiple rows
- If you see ${invoiceCountInfo.invoiceCount || 'multiple'} rows in the table, extract ${invoiceCountInfo.invoiceCount || 'all'} separate invoice objects
- Each invoice object should correspond to ONE row in the statement table

`;
    } else if (invoiceCountInfo.hasMultipleInvoices === false) {
      invoiceCountContext = `

INVOICE COUNT ANALYSIS:
✅ This document has been analyzed and contains a SINGLE invoice.
- Expected invoice count: 1
- Reason: ${invoiceCountInfo.reason || 'Single invoice document detected'}

EXTRACTION REQUIREMENTS FOR SINGLE INVOICE:
- Extract the invoice number from the document header/title (e.g., "Invoice No. XXX")
- Return an array with EXACTLY ONE invoice object
- Do NOT create multiple invoice objects

`;
    }
  }

  const sysPrompt = `You are an expert financial document parser specializing in invoice and statement extraction. Your task is to accurately extract ALL invoice records from the provided document data.
${errorContext}${invoiceCountContext}
CRITICAL RULES:
1. Extract ONLY information that is explicitly visible in the document. Never guess, infer, or assume values.
2. If a field is missing or unclear, set it to null. Do NOT make up values.
3. You MUST extract EVERY invoice/transaction present in the document, even if some fields are incomplete.
4. Output MUST be valid JSON only - no markdown, no explanations, no code blocks.

FILE CONTEXT:
- File name: ${fileName || 'Not provided'}
- This may be a statement of account, invoice list, or transaction summary

REQUIRED JSON STRUCTURE:
{
  "fileDate": "yyyy-mm-dd",  // Date the file/document was created/issued (extract from document header, footer, or metadata)
  "invoices": [
    {
      "invoiceDate": "dd/mm/yyyy",  // Date of the individual invoice
      "invoiceNumber": "string",     // Invoice/Reference/Transaction number (preserve exactly as shown)
      "activityDescription": "string", // Description of goods/services/transaction
      "amount": {
        "amount": number,      // Subtotal/amount before tax (numeric, no currency symbols)
        "tax_fees": number     // Tax, VAT, or fees amount (numeric, default 0 if not present)
      },
      "currency": "string",    // Currency symbol: "$", "£", "€", "¥", etc. (extract from document)
      "paymentStatus": "paid" | "unpaid"  // Determine from payment indicators, dates, or status fields
    }
  ]
}

FIELD EXTRACTION GUIDELINES:

- invoiceDate: Look for "Date", "Invoice Date", "Transaction Date", "Due Date" columns/fields. Format as dd/mm/yyyy.
- invoiceNumber: **CRITICAL - Each invoice MUST have a UNIQUE invoice number**
  * **SINGLE INVOICE FILES**: If the document contains only ONE invoice (not a statement/table), extract the invoice number from the document header/title (e.g., "Invoice No. AAA-S-16129"). Return an array with ONE invoice object.
  * **STATEMENT FILES**: If the document is a statement of account with a table of multiple invoices, extract the invoice number from EACH ROW/ENTRY in the table. Each row = one separate invoice.
  * Look in columns like "Our Reference", "Invoice No.", "Reference", "Transaction ID", "Invoice Number", "Doc Number"
  * Each row in a statement table represents a SEPARATE invoice with its OWN unique invoice number
  * Preserve the invoice number EXACTLY as shown (leading zeros, letters, hyphens, etc.)
  * DO NOT reuse the same invoice number for multiple invoices - each invoice must be unique
  * If a statement has 8 rows, you must extract 8 different invoice numbers, one per row
  * If a file has only 1 invoice, return an array with 1 invoice object (not multiple with the same number)
- activityDescription: Extract from "Description", "Item", "Details", "Narrative", "Memo" fields. Include full text.
- amount.amount: Extract from "Amount", "Subtotal", "Total", "Net Amount" fields. Remove currency symbols, commas, convert to number.
- amount.tax_fees: Extract from "Tax", "VAT", "Fees", "GST" fields. Default to 0 if not present.
- currency: Identify from currency symbols ($, £, €, etc.) or currency codes (USD, GBP, EUR) in the document. Convert codes to symbols.
- paymentStatus: 
  * "paid" if you see: "Paid", "Settled", "Cleared", payment date present, or balance is zero
  * "unpaid" if you see: "Outstanding", "Pending", "Due", "Unpaid", or balance > 0
  * Default to "unpaid" if unclear
- fileDate: Extract from document header ("Statement Period", "As of", "Date Generated"), footer, or file metadata. Format as yyyy-mm-dd.

SPECIAL CASES:
- **SINGLE INVOICE DOCUMENTS**: If the file contains a single invoice (not a statement), treat the entire document as ONE invoice. Extract the invoice number from the header/title. Return an array with ONE invoice object.
- **STATEMENT DOCUMENTS**: If the file is a statement of account with a table/list of multiple invoices, each row/entry = ONE separate invoice object with its own unique invoice number
- For Excel files: Process all sheets, each row with an invoice number = separate invoice object
- For PDFs: Extract text from all pages, look for tables and structured data
- Multiple invoices per document: Create separate invoice objects, each with its own unique invoice number
- Credits/Refunds: Include as separate invoices with negative amounts if applicable, each with unique invoice number
- Partial data: Include invoice even if only invoiceNumber is available, but invoiceNumber is REQUIRED
- **CRITICAL**: NEVER create multiple invoice objects with the same invoice number. If there's only one invoice in the file, return ONE invoice object. If there are multiple invoices, each must have a unique invoice number.

OUTPUT FORMAT:
Return ONLY valid JSON matching the structure above. No markdown code blocks, no explanations, no additional text.

Example valid output:
{
  "fileDate": "2024-11-15",
  "invoices": [
    {
      "invoiceDate": "15/10/2024",
      "invoiceNumber": "INV-2024-001",
      "activityDescription": "Professional services for Q3 2024",
      "amount": { "amount": 1500.00, "tax_fees": 300.00 },
      "currency": "$",
      "paymentStatus": "unpaid"
    },
    {
      "invoiceDate": "20/10/2024",
      "invoiceNumber": "INV-2024-002",
      "activityDescription": "Consulting services",
      "amount": { "amount": 850.50, "tax_fees": 170.10 },
      "currency": "$",
      "paymentStatus": "paid"
    }
  ]
}`;

  const aiRes = await geminiCall(text, sysPrompt);
  return aiRes;
}


async function findMatchingCompanyWithAIFromAList(name, fileName, email, contacts) {
  const sysPrompt = `You are an expert at matching company names to contact records in accounting systems.

TASK:
Identify the SINGLE contact record that best matches the provided company name from the list of contacts.

MATCHING STRATEGY:
1. Exact matches (case-insensitive, ignoring punctuation and spacing)
2. Partial matches (company name contains or is contained in contact name)
3. Abbreviation matches (e.g., "Ltd" = "Limited", "Inc" = "Incorporated")
4. Common variations (punctuation, spacing, capitalization differences)
5. Phonetically similar names
6. Acronym matches (if company name is an acronym of contact name or vice versa)

CONTEXT INFORMATION:
- Company name to match: "${name}"
- File name: "${fileName}"
- Email (if available): "${email}"

CONTACT RECORDS:
${JSON.stringify(contacts, null, 2)}

MATCHING RULES:
- Prioritize contacts with balance information (Balances field present)
- If multiple matches exist, choose the one with the most complete data
- Consider the file name as additional context (may contain company name variations)
- Return the ContactID (GUID) of the best match

OUTPUT REQUIREMENTS:
- Return ONLY valid JSON in this exact format:
{ "id": "CONTACT_ID_GUID" }
- The id must be a valid GUID/UUID format
- No explanations, no markdown, no additional text
- If no reasonable match exists, return the closest match anyway

Example output:
{ "id": "12345678-1234-1234-1234-123456789abc" }`;

  const aiResponse = await geminiCall(name, sysPrompt);
  return aiResponse;
}


async function findMatchingCompanyWithAI(email, fileName, content) {
  const systemPrompt = `You are an expert at identifying company/supplier names from financial documents and file metadata.

TASK:
Extract the supplier's or company's name from the provided information. This is the entity that issued the invoice or statement.

INFORMATION PROVIDED:
- Email (sender/recipient): ${email || 'Not provided'}
- File name: ${fileName || 'Not provided'}
- File content (first 2000 characters): ${content ? content.substring(0, 2000) : 'Not provided'}

EXTRACTION GUIDELINES:
1. Look for company names in:
   - Document headers/footers ("From:", "Issued by:", "Company Name")
   - Letterhead or branding
   - File name (often contains company name)
   - Email domain or sender name
   - "Supplier:", "Vendor:", "From Company:" fields
   - Statement headers

2. EXCLUDE these common patterns:
   - "Insperanto LTD" or "Insperanto Limited" (this is typically the receiving company)
   - Generic terms like "Statement", "Invoice", "Account"
   - Date ranges or periods
   - File extensions or metadata

3. PREFERRED FORMAT:
   - Full legal company name if available
   - Include business suffixes (Ltd, LLC, Inc, etc.) if present
   - Preserve capitalization as it appears in the document
   - Remove extra whitespace

4. VALIDATION:
   - Must be a recognizable company/business name
   - Should not be a generic term or document type
   - Should not be the receiving company (Insperanto)

OUTPUT:
- Return ONLY the company name as a plain string
- No explanations, no quotes, no additional text
- If uncertain, return the most likely company name based on the evidence
- If no company name can be identified, return an empty string

Example outputs:
"Adams & Associates Ltd"
"Stolmar Trading Company"
"Takoa Industries"`;

  const aiResponse = await geminiCall('', systemPrompt);
  return aiResponse?.trim();
}



async function checkMultipleInvoiceNumbers(text, fileName = '') {
  const sysPrompt = `You are an expert financial document analyzer. Your task is to determine if a document contains ONE invoice or MULTIPLE invoices.

TASK:
Analyze the provided document content and determine:
1. Does this document contain a SINGLE invoice (one invoice number)?
2. Or does it contain MULTIPLE invoices/transactions (multiple invoice numbers)?

FILE CONTEXT:
- File name: ${fileName || 'Not provided'}
- This may be a single invoice, a statement of account, an invoice list, or a transaction summary

ANALYSIS GUIDELINES:

SINGLE INVOICE INDICATORS:
- Document has ONE invoice number in the header/title (e.g., "Invoice No. AAA-S-16129")
- Document is structured as a single invoice with one set of line items
- No table or list of multiple transactions
- Single total amount, single invoice date
- Document title contains "Invoice" (singular)

MULTIPLE INVOICES INDICATORS:
- Document is a "Statement of Account" or "Account Statement"
- Contains a TABLE with multiple rows, each row representing a different invoice/transaction
- Multiple invoice numbers visible (e.g., in different rows or entries)
- Multiple transaction dates
- Document title contains "Statement", "Summary", "List", or similar plural terms
- Multiple line items with different invoice/reference numbers

OUTPUT REQUIREMENTS:
Return ONLY valid JSON in this exact format:
{
  "hasMultipleInvoices": true | false,
  "invoiceCount": number | null,
  "reason": "brief explanation"
}

- hasMultipleInvoices: true if document contains multiple invoices/transactions, false if it's a single invoice
- invoiceCount: The number of invoices/transactions found (null if cannot determine)
- reason: Brief explanation of why you determined single vs multiple (e.g., "Single invoice with one invoice number in header" or "Statement table with 8 rows, each with different invoice numbers")

Example outputs:
{
  "hasMultipleInvoices": false,
  "invoiceCount": 1,
  "reason": "Single invoice document with one invoice number in header"
}

{
  "hasMultipleInvoices": true,
  "invoiceCount": 8,
  "reason": "Statement of account with table containing 8 rows, each row has a different invoice number"
}

{
  "hasMultipleInvoices": true,
  "invoiceCount": null,
  "reason": "Statement table visible but exact count unclear from content preview"
}`;

  const aiRes = await geminiCall(text, sysPrompt);
  
  // Parse the response
  try {
    let cleaned = aiRes.replace(/```json/gi, '').replace(/```/gi, '').trim();
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    return JSON.parse(cleaned);
  } catch (parseError) {
    console.error('Failed to parse invoice count check response:', parseError);
    // Return default response
    return {
      hasMultipleInvoices: null,
      invoiceCount: null,
      reason: 'Failed to parse AI response'
    };
  }
}

module.exports = { formatWithAIToStandardJSON, findMatchingCompanyWithAIFromAList, findMatchingCompanyWithAI, checkMultipleInvoiceNumbers };
