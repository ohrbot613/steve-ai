const express = require("express");
require('dotenv').config();
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const appRoutes = require("./app");
const { errorHandler } = require("./controllers/ErrorController");
const app = express();
const path = require("path");



(async () => {
    try {
        const mongoUri = process.env.MONGO_URI;
        
        if (!mongoUri) {
            throw new Error("MONGO_URI environment variable is not set. Please set it in your production environment variables or .env file.");
        }
        
        await mongoose.connect(mongoUri, {
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
        });
        console.log("MongoDB connected successfully");
    } catch (error) {
        console.error("MongoDB connection failed:", error.message);
        process.exit(1); // Exit process if database connection fails
   }   
})()

app.set("view engine", "ejs");       // or pug, hbs, etc.
app.set("views", path.join(__dirname, "views"));

app.use(cookieParser());
app.use(appRoutes);
app.use(errorHandler);

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`PDF server running on http://localhost:${PORT}`);
});
