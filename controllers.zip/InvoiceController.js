const { fileTypeFromBuffer } = require("file-type");
const { tryCatchAsync } = require("./ErrorController");
const fs = require("fs");
const XLSX = require('xlsx');
const mongoose = require("mongoose");
const { PDFParse } = require("pdf-parse");
const { findMatchingCompanyWithAI, formatWithAIToStandardJSON, findMatchingCompanyWithAIFromAList } = require("../formatting");
const axios = require("axios");
const Invoices = require("../modals/invoiceModal");
const Suppliers = require("../modals/supplierModal");
const Logs = require("../modals/logsModal");
const path = require("path");
const { v4: uuidv4 } = require("uuid"); // for unique IDs
const multer = require('multer');

const storage = multer.memoryStorage();


// File filter to only accept PDF and XLSX
const fileFilter = (req, file, cb) => {
    const allowedTypes = ['application/pdf',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];

    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true); // accept file
    } else {
        cb(new Error('Only PDF and XLSX files are allowed'), false); // reject file
    }
};

exports.upload = multer({ storage, fileFilter });


exports.parseFiles = tryCatchAsync(async (req, res) => {
    const accessToken = req.xeroAccessToken
    const tenantId = req.xeroTenantId



    function errorCallback(res, req, err) {
        console.log(err)
        return res.status(500).json(err);
    }

    async function loop(logic, message) {
        let attempts = 0;
        const maxAttempts = 3;
        let success = false;
        let data = false;

        while (!success && attempts < maxAttempts) {
            attempts++;

            try {
                data = await logic();
                success = true
            } catch (err) {
                console.log(err)
                success = false;
            }
        }

        if (!success) {
            console.error('Unable to complete after maximum attempts');
            throw new Error(message || 'Unable to complete after maximum attempts');
        }

        console.log("Success after", attempts, "attempts", success);

        return data
    }

    const filePath = "./file.pdf"; // change to your file


    let newFileName
    let dataForAi = await parseFile(filePath)

    async function parseFile(filePath) {
        const fileBuffer = req.file.buffer;

        const folderPath = path.join(__dirname, "../media/files"); // your folder
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true }); // make folder if not exists
        }

        const uniqueName = uuidv4() + path.extname(filePath); // keep original extension
        const savePath = path.join(folderPath, uniqueName);
        newFileName = uniqueName
        fs.writeFileSync(savePath, fileBuffer);

        const type = await fileTypeFromBuffer(fileBuffer);
        if (type.ext == 'xlsx') {
            const workbook = XLSX.readFile(filePath);
            const allRecords = [];

            workbook.SheetNames.forEach(sheetName => {
                const sheet = workbook.Sheets[sheetName];
                const records = XLSX.utils.sheet_to_json(sheet, { defval: null });
                records.forEach(r => r.sheetName = sheetName);
                allRecords.push(...records);
            });

            return allRecords
        } else if (type.ext == 'pdf') {
            const parser = new PDFParse({ data: fileBuffer });
            const fileData = await parser.getText();
            if (parser.destroy) await parser.destroy();
            return fileData.text
        } else {
            return errorCallback(res, req, `File type not supported ${type.ext}`);
        }
    }


    const companyArray = []

    async function getCompanyName(email, fileName, content) {
        await loop(async () => {
            const name = await findMatchingCompanyWithAI(email, fileName, content)
            if (!name || name.trim().length == 0) {
                return false
            }

            companyArray.push(name)
            companyArray.push(...name.replace(/[^a-zA-Z0-9\s]/g, '').split(" "))
            companyArray.push(...name.replace(/[^a-zA-Z0-9\s]/g, '').split(" ").map((item) => item.toUpperCase()))
            companyArray.push(...name.replace(/[^a-zA-Z0-9\s]/g, '').split(" ").map((item) => item.toLowerCase()))
            companyArray.push(
                ...name
                    .replace(/[^a-zA-Z0-9\s]/g, '')
                    .split(" ")
                    .map(item => item.charAt(0).toUpperCase() + item.slice(1).toLowerCase())
            );
        }, "Failed to get company name from AI")

    }

    const email = ''
    const fileName = "Adams Statement of Account_134221_Nov 2025.PDF"
    let invoiceIssueDate
    await getCompanyName(email, fileName, dataForAi)

    const invoicesFromFile = await loop(async () => {
        const format = await formatWithAIToStandardJSON(JSON.stringify(dataForAi));

        const removeJSON = format.replace(/```/gi, '').replace(/JSON/gi, '');
        const invoicesObj = JSON.parse(removeJSON);
        function toValidDate(value) {
            if (!value) return null;
            
            const date = new Date(value);
            return isNaN(date.getTime()) ? null : date;
        }
        
        console.log(invoicesObj.fileDate, toValidDate(invoicesObj.fileDate))
        // usage
        invoiceIssueDate = toValidDate(invoicesObj.fileDate)
         return invoicesObj.invoices.map(inv => ({ ...inv, invoiceNumber: inv.invoiceNumber }))
    }, 'Failed to format file data with AI')


    const contactsArray = await (async () => {
        const filter = companyArray
            .filter(word => word.trim() !== "")
            .map(word => `Name.Contains("${encodeURIComponent(word)}")`)
            .join(" OR ");

        const url =
            `https://api.xero.com/api.xro/2.0/Contacts?where=${filter}`


        const response = await axios.get(url, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Xero-tenant-id': tenantId,
                Accept: 'application/json'
            }
        });
        // const contacts = response?.data?.Contacts;
        const allContacts = response?.data?.Contacts || [];
        const contacts = allContacts.filter(ct => ct.Balances);

        // Log the ones that were filtered out
        allContacts.forEach(ct => {
            if (!ct.Balances) {
                // console.log(`Filtered out: ${ct.Name}, Balance: ${ct.Balance || 0}`);
            }
        });
        if (contacts.length == 0) {
            return errorCallback(res, req, "No contacts found.")
        }


        return contacts;
    })();




    const contactId = await loop(async () => {
        const contactIdJson = await findMatchingCompanyWithAIFromAList(companyArray[0], fileName, email, contactsArray)
        const contactId = JSON.parse(contactIdJson.replace(/```json/gi, '').replace(/```/gi, '')).id

        const isXeroContactId = (id) =>
            /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);

        if (!isXeroContactId(contactId)) {
            throw new Error("No contact id found from AI")
        }

        return contactId
    })

    let supplierInfo = await Suppliers.findOne({ xeroId: contactId })
    if (!supplierInfo) {
        supplierInfo = await Suppliers.create({ xeroId: contactId, name: contactsArray.find((ct) => ct.ContactID == contactId).Name })
    }


    const logDoc = await Logs.create({ supplier: supplierInfo._id, status: 'Started', file: newFileName, invoiceIssueDate })
    try {


        async function getInvoicesFromXero() {
            const today = new Date();
            const twoMonthsAgo = new Date(today);
            twoMonthsAgo.setMonth(today.getMonth() - 2);

            const lastInvoiceFromSupplier = await Invoices.findOne({ supplier: supplierInfo._id }).sort({ createdAt: -1 })
            const date = new Date(lastInvoiceFromSupplier?.addedAt ?? twoMonthsAgo);
            const fromDate = `${date.getFullYear()},${String(date.getMonth() + 1).padStart(2, '0')},${String(date.getDate()).padStart(2, '0')}`;
            // TODO: update the dates
            const where = `
                            Contact.ContactID == Guid("${contactId}")
                            AND Date >= DateTime(${fromDate})`;


            const invoiceUrl = `https://api.xero.com/api.xro/2.0/Invoices?where=${encodeURIComponent(where)}`;
            const invoiceResponse = await axios.get(invoiceUrl, {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    'Xero-tenant-id': tenantId,
                    Accept: 'application/json',
                },
            });

            return invoiceResponse.data.Invoices
        }

        const invoicesArray = await getInvoicesFromXero()

        const formattedXeroInvoices = invoicesArray.map(inv => {
            return {
                invoiceDate: new Date(inv.DateString).toLocaleDateString('en-GB'),
                invoiceNumber: inv.InvoiceNumber,
                activityDescription: null, // fill if needed
                amount: {
                    amount: inv.SubTotal,
                    tax_fees: inv.TotalTax
                },
                currency: inv.CurrencyCode === 'USD' ? '$' : '€',
                paymentStatus: inv.Status === 'AUTHORISED' ? 'unpaid' : 'paid', // adjust mapping if needed
            };
        }).map(inv => ({ ...inv, invoiceNumber: inv.invoiceNumber?.replace(/\D/g, '') }))
        // .filter(inv => inv.paymentStatus === 'unpaid')

        function matchInvoices(formattedXeroInvoices, invoicesFromFile) {
            const mapXero = new Map();
            const mapFile = new Map();

            // Map invoices by InvoiceNumber
            formattedXeroInvoices.forEach(inv => mapXero.set(inv.invoiceNumber.replace(/\D/g, ''), inv));
            invoicesFromFile.forEach(inv => mapFile.set(inv.invoiceNumber.replace(/\D/g, ''), inv));

            // Get all unique InvoiceNumbers
            const allInvoiceNumbers = new Set([
                ...mapXero.keys(),
                ...mapFile.keys()
            ]);

            // Build pairs
            const items = [];
            allInvoiceNumbers.forEach(num => {
                const xeroInv = mapXero.get(num) || null;
                const fileInv = mapFile.get(num) || null;
                items.push([xeroInv, fileInv]);
            });

            return items;
        }

        function getInvoiceKeys(invoiceNumber) {
            const raw = invoiceNumber.trim();
            const digitsOnly = raw.replace(/\D/g, '');

            return new Set([
                raw,
                digitsOnly
            ]);
        }


        const matchedInvoices = matchInvoices(formattedXeroInvoices, invoicesFromFile);


        const mismatch = matchedInvoices.filter(
            item =>
                item[0] == null ||
                item[1] == null
        ).length;



        matchedInvoices.forEach(async ([xeroInv, fileInv]) => {
            await Invoices.create({
                invoiceDate: fileInv ? new Date(fileInv.invoiceDate?.split('/').reverse().join('-')) : null,
                invoiceXeroDate: xeroInv ? new Date(xeroInv.invoiceDate?.split('/').reverse().join('-')) : null,
                invoiceNumber: fileInv ? fileInv.invoiceNumber : xeroInv.invoiceNumber,
                activityDescription: fileInv ? fileInv.activityDescription : null,
                amountXero: xeroInv ? { amount: xeroInv.amount.amount ?? 0, taxFees: xeroInv.amount.tax_fees ?? 0 } : null,
                amount: fileInv ? { amount: fileInv.amount.amount ?? 0, taxFees: fileInv.amount.tax_fees ?? 0 } : null,
                currency: fileInv ? fileInv.currency : xeroInv.currency,
                paymentStatus: fileInv ? fileInv.paymentStatus : xeroInv.paymentStatus,
                supplier: supplierInfo._id
            })
        })

        await Logs.updateOne({ _id: logDoc._id }, { status: `Completed`, found: invoicesFromFile.length, errors: mismatch })
        res.redirect('/')
        // res.status(200).json({
        //     success: true,
        //     text: invoicesArray
        // });
    } catch (error) {
        await Logs.updateOne({ _id: logDoc._id }, { status: error.message })
        res.redirect('/')
        //     res.status(200).json({
        //         success: false,
        //         text: []
        //     });
    }
});

exports.getInvoices = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const id = req.query.id;
    const offset = (page - 1) * limit;

    const invoices = await Invoices.find({ supplier: id })
        .sort({ invoiceXeroDate: 1 })  // Sort ascending
        .skip(offset)           // Skip `offset` documents
        .limit(limit);          // Limit the number of results

    const total = await Invoices.countDocuments({ supplier: id });
    res.status(200).json({
        success: true,
        invoices,
        pages: Math.ceil(total / limit)
    });
});

exports.getAllInvoices = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const offset = (page - 1) * limit;

    const invoices = await Invoices.find()
        .sort({ addedAt: -1 })  // Sort ascending
        .skip(offset)           // Skip `offset` documents
        .limit(limit)   // Limit the number of results
.populate('supplier');
    const total = await Invoices.countDocuments();
    res.status(200).json({
        success: true,
        invoices,
        pages: Math.ceil(total / limit)
    });
});

exports.getAllLogs = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const offset = (page - 1) * limit;

    const logs = await Logs.find()
        .sort({ addedAt: -1 })  // Sort ascending
        .skip(offset)           // Skip `offset` documents
        .limit(limit)   // Limit the number of results
.populate('supplier');
    const total = await Logs.countDocuments();
    res.status(200).json({
        success: true,
        logs,
        pages: Math.ceil(total / limit)
    });
});

exports.getSuppliers = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const search = req.query.search || '';
    const offset = (page - 1) * limit;

    const matchStage = search
        ? { name: { $regex: search, $options: 'i' } }
        : {};

    const suppliers = await Suppliers.aggregate([
        { $match: matchStage },

        // Join invoices
        {
            $lookup: {
                from: 'invoices',          // collection name (plural, lowercase)
                localField: '_id',
                foreignField: 'supplier',  // field in invoices
                as: 'invoices'
            }
        },

        // Count invoices
        {
            $addFields: {
                invoiceCount: { $size: '$invoices' }
            }
        },

        // Sort A → Z
        { $sort: { name: 1 } },

        // Pagination
        { $skip: offset },
        { $limit: limit },

        // Optional: remove invoice array from response
        {
            $project: {
                invoices: 0
            }
        }
    ]);

    const total = await Suppliers.countDocuments(matchStage);

    res.status(200).json({
        success: true,
        suppliers,
        pages: Math.ceil(total / limit)
    });
});


exports.getLogs = tryCatchAsync(async (req, res) => {
    const limit = 50;
    const page = Number(req.query.page) || 1;
    const id = req.query.id;
    const offset = (page - 1) * limit;

    const logs = await Logs.find({ supplier: id })
        .sort({ addedAt: -1 })  // Sort ascending
        .skip(offset)           // Skip `offset` documents
        .limit(limit);          // Limit the number of results

    const total = await Logs.countDocuments({ supplier: id });

    res.status(200).json({
        success: true,
        logs,
        pages: Math.ceil(total / limit)
    });
});
