const { tryCatchAsync } = require("./ErrorController");
const Logs = require("../modals/logsModal");
const path = require("path");
const fs = require("fs");
exports.home = tryCatchAsync(async (req, res) => {
    res.status(200).render("home");
});
exports.login = tryCatchAsync(async (req, res) => {
    res.status(200).render("login");
});

exports.logs = tryCatchAsync(async (req, res) => {
    res.status(200).render("logs");
});

exports.statements = tryCatchAsync(async (req, res) => {
    res.status(200).render("statements");
});

exports.allStatements = tryCatchAsync(async (req, res) => {
    res.status(200).render("allStatements");
});


exports.allLogs = tryCatchAsync(async (req, res) => {
    res.status(200).render("allLogs");
});


exports.file = tryCatchAsync(async (req, res) => {
    const fileId = req.params.file; // the file name or id

    const item = await Logs.findOne({ _id: fileId });
    if (!item || !item.file) return res.status(404).send('File not found');

    const filePath = path.join(__dirname, "../media/files", item.file); // adjust path
    // Check if file exists
    if (!fs.existsSync(filePath)) {
        return res.status(404).send('File not found');
    }

    // Determine file type
    const ext = path.extname(filePath).toLowerCase();
    let contentType = '';
    if (ext === '.pdf') contentType = 'application/pdf';
    else if (ext === '.xlsx') contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    else return res.status(400).send('Unsupported file type');

    res.setHeader('Content-Type', contentType);

    // If you want the browser to display inline (PDF viewable in browser)
    res.setHeader('Content-Disposition', 'inline; filename="' + path.basename(filePath) + '"');

    // Stream the file
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
});