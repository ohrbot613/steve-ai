exports.tryCatchAsync = (fn) => {
    return (req, res, next) => {
        fn(req, res, next).catch(next);
    };
}

exports.AppError = class AppError extends Error {
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.status = `${statusCode}`.startsWith("4") ? "fail" : "error";
        this.isOperational = true;

        Error.captureStackTrace(this, this.constructor);
    }
}

exports.errorHandler = (err, req, res, next) => {
    // Log error to console
    console.error("Error 💥:", err);

    // If it's an AppError, send its message
    if (err instanceof this.AppError) {
        return res.status(err.statusCode).json({
            status: err.status,
            message: err.message
        });
    }

    // Fallback for unknown errors
    res.status(500).json({
        status: "error",
        message: "Something went wrong!",
        err: err
    });
};